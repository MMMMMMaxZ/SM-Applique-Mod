--MAXZ666--
MHUD = class(nil)
MHUD.maxParentCount = 1
MHUD.connectionInput = sm.interactable.connectionType.logic+sm.interactable.connectionType.power

MHUD.colorNormal = sm.color.new(0x14514ff)
MHUD.colorHighlight = sm.color.new(0x114514aa)

----------------------------------server
function MHUD.server_onCreate(self)
    
end

function MHUD.server_onFixedUpdate(self,dt)
    self.input = self.interactable:getSingleParent()
    if self.input ~= nil then 
        self.inputActive = self.input:isActive()
        self.inputPower = self.input.power
        if self.inputPower == 0 and self.inputActive then self.inputPower = 1 end
        --createEffect
        if self.lastInput ~= nil then
            if self.lastInput ~= self.inputActive then
                if self.inputActive then
                    --self.network:sendToClients("client_startEffect")
                    if tostring(self.input.shape.color) ~= self.colorWhite then
                        self.interactable:setActive(true)
                    end
                else
                    self.interactable:setActive(false)
                    --self.network:sendToClients("client_endEffect")
                end
            end
        end
        self.lastInput = self.inputActive
    end

    --main
    if self.interactable.active then
        --[[print("PRINT\n\n")
        print(self.shape.worldPosition)
        local X = sm.vec3.new(1,0,0)
        local Y = sm.vec3.new(0,1,0)
        local Z = sm.vec3.new(0,0,1)
        local t = sm.vec3.normalize(sm.vec3.new(self.shape.at:dot(X),self.shape.at:dot(Y),0))
        print(t,"\n")
        print(self.shape.worldRotation*sm.vec3.new(0,1,0))
        print(self.shape.at)
        print(self.shape.worldRotation*sm.vec3.new(0,0,1))
        print(self.shape.up)
        print("\n\n")]]
    end
    --end
end
----------------------------------client
function MHUD.client_onCreate(self)
    self.HUD1 = sm.effect.createEffect("HUD1")
    self.HUD2 = sm.effect.createEffect("HUD2",self.interactable)
    self.lastInp = false
    self.lastVel = self.shape.velocity
end

function MHUD.client_onUpdate(self,dt)
    if self.interactable:isActive() then
        if self.lastInp == false then
            self.HUD1:start()
            self.HUD2:start()
        end
        local v = self.shape.velocity
        local a = v-self.lastVel
        self.HUD1:setPosition(self.shape:getWorldPosition()+(v+a)*dt*0.8)
        local X = sm.vec3.new(1,0,0)
        local Y = sm.vec3.new(0,1,0)
        local t = sm.vec3.normalize(sm.vec3.new(self.shape.at:dot(X),self.shape.at:dot(Y),0))
        self.HUD1:setRotation(sm.vec3.getRotation(sm.vec3.new(0,1,0),t))
    else
        self.HUD1:stop()
        self.HUD2:stop()
    end
    self.lastInp = self.interactable:isActive()
    self.lastVel = self.shape.velocity
end