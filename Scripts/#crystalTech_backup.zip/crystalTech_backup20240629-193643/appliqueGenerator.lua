-- MAXZ666 --
-- Max's applique generator
MAG = class(nil)
MAG.maxParentCount = 1
MAG.connectionInput = sm.interactable.connectionType.logic+sm.interactable.connectionType.power

MAG.colorNormal = sm.color.new(0x14514ff)
MAG.colorHighlight = sm.color.new(0x114514aa)

MAG.effectPlayer = {"MaxZ666","Public","End"}
MAG.efctPlyrCnt = {1,2,7}
MAG.effectList = {"testEffect","A","S","G","W","ManualRelease","lazer"}

--server
function MAG.server_onCreate(self)
    self.Server_effectTable = self.storage:load()
    if(self.Server_effectTable==nil)then
        self.Server_effectTable={}
    end
    self.Server_tableCnt = #self.Server_effectTable
    self.network:sendToClients("client_getSavedData",self.Server_effectTable)
end

function MAG.server_onFixedUpdate(self,dt)
    self.input = self.interactable:getSingleParent()
    if self.input ~= nil then
        self.inputActive = self.input:isActive()
    else
        self.inputActive = false
    end
    if self.inputActive then
        self.interactable:setActive(true)
    else 
        self.interactable:setActive(false)
    end
end

function MAG.server_saveData(self,data)
    self.Server_effectTable = {}
    local i=1
    --print("saveeee\n")
    for idx,data in pairs(data)do
        --print("data[",idx,"]")
        --print(data)
        if not data.cleanFlag then
            self.Server_effectTable[i] = data
            i = i + 1
        end
    end
    --print("\n",self.Server_effectTable)
    self.storage:save(self.Server_effectTable)
    self.network:sendToClients("client_getSavedData",self.Server_effectTable)
    --print("\n\n")
end

function NearestPlayer(position , playerList)
	local distance  = nil
	local oupPlayer = nil
	for k,v in pairs(playerList)do
		local vD = sm.vec3.length2(position - v.character.worldPosition)
		if distance == nil or vD<distance then
			distance = vD
			oupPlayer = v
		end
	end
	return oupPlayer
end

--client

function MAG.client_onCreate(self)
    self.currentEffect = sm.effect.createEffect("testEffect",self.interactable)
    self.effectTableData = {}
    self.effectTable = {}
    self.tableCnt = 0

    self.currentRotation = 3
    self.currentEffectId = 1
    self.maxEffectId = #self.effectList
    self.currentEfctPlyr = 1
    self.currentEfctPlus = 0

    self.localPlayer = sm.localPlayer.getPlayer()
    self.ready = true
    self.lastState = false -- false未启动，true启动
end

function MAG.client_getSavedData(self,savedTable)
    self.effectTableData = savedTable
    self:translateData(self.effectTableData)
    self.tableCnt = #self.effectTableData + 1
end

function MAG.translateData(self,inputData)
    self.effectTable = {}
    --print("\n\n -- client_translate -- \n")
    for idx,data in pairs(inputData)do
        --print("data[",idx,"]")
        --print(data)
        --if self.effectTable[idx] ~= nil then self.effectTable[idx]:destroy() end
        self.effectTable[idx] = sm.effect.createEffect(self.effectList[data.id],self.interactable)
        self.effectTable[idx]:setOffsetPosition(sm.vec3.new(data.offsetPosition.x,data.offsetPosition.y,data.offsetPosition.z))
        self.effectTable[idx]:setOffsetRotation(sm.quat.new(data.offsetRotation.x,data.offsetRotation.y,data.offsetRotation.z,data.offsetRotation.w))
        self.effectTable[idx]:start()
    end
    --print("\n -- client_end -- \n\n")
end

function MAG.changeCurrentEffect(self)
    self.currentEffect:destroy()
    self.currentEffect = sm.effect.createEffect(self.effectList[self.currentEffectId],self.interactable)
    self.currentEffect:start()
end

function MAG.findEfctPlyr(self)
    local oup
    for k,v in pairs(self.efctPlyrCnt)do
        if self.currentEffectId >=v and self.currentEffectId <self.efctPlyrCnt[k+1] then
            oup = k
        end
    end
    self.currentefctPlyr = oup
    self.currentEfctPlus = self.currentEffectId - self.currentefctPlyr
end

function MAG.client_onFixedUpdate(self,dt)
    if self.shape.body:isOnLift() then
        for idx,efct in pairs(self.effectTable)do
            if not efct:isPlaying() then
                efct:start()
            end
        end
    end
    if self.interactable:isActive()then
        if self.lastState == false then --第一次启动获取最近玩家并绑定
            self.lastState = true
            local allPlayers = sm.player.getAllPlayers()
            self.currentPlayer = NearestPlayer(self.shape.worldPosition,allPlayers)
            self.currentCharacter = self.currentPlayer.character
            self.currentEffect:start()
        end
        if self.localPlayer == self.currentPlayer then 
            local get,result = sm.localPlayer.getRaycast(10)
            if get then
                local hitLocation = result.pointWorld
                local hitNormal = result.normalWorld
                local offR = sm.vec3.getRotation(self.shape.at,hitNormal)
                local fixRotation = sm.quat.inverse(self.shape.worldRotation)
                local offP = fixRotation*(hitLocation-self.shape.worldPosition)

                local efctUp = offR*self.shape.up
                local efctRight = offR*self.shape.right
                local efctRotaOnce = sm.vec3.getRotation(efctUp,efctRight)
                local efctRota = efctRotaOnce
                for i=0,self.currentRotation do
                    efctRota = efctRota*efctRotaOnce
                end
                offR = efctRota*offR

                if not self.currentCharacter:isAiming() then
                    self.ready = true
                    self.currentEffect:setOffsetPosition(fixRotation*(hitLocation-self.shape.worldPosition))
                    self.currentEffect:setOffsetRotation(offR)
                elseif self.ready then
                    if not self.currentCharacter:isCrouching() then
                        self.ready = false
                        self.effectTable[self.tableCnt]=sm.effect.createEffect(self.effectList[self.currentEffectId],self.interactable)
                        self.effectTable[self.tableCnt]:setOffsetPosition(offP)
                        self.effectTable[self.tableCnt]:setOffsetRotation(offR)
                        self.effectTable[self.tableCnt]:start()
                        self.effectTableData[self.tableCnt]={
                            id = self.currentEffectId ,
                            offsetPosition = {x=offP.x,y=offP.y,z=offP.z},
                            offsetRotation = {x=offR.x,y=offR.y,z=offR.z,w=offR.w},
                            cleanFlag = false
                        }
                        self.tableCnt = self.tableCnt + 1
                        --print(self.tableCnt-1)
                    elseif #self.effectTableData > 0 then
                        local nIdx,nDistance = 1,1000
                        for idx,data in pairs(self.effectTableData)do
                            local ofp = offP - sm.vec3.new(data.offsetPosition.x,data.offsetPosition.y,data.offsetPosition.z)
                            local ofpd = ofp:length()
                            if ofpd <= nDistance then
                                nDistance = ofpd
                                nIdx = idx
                            end
                        end
                        self.effectTableData[nIdx].cleanFlag = true
                        --print(self.effectTable[nIdx]:isPlaying())
                        self.effectTable[nIdx]:stop()
                    end
                end
            end
        end
    else
        if self.lastState == true then
            if self.localPlayer == self.currentPlayer then 
                self.currentEffect:stop()
                --send back data
                sm.gui.displayAlertText("sending data to server 同步数据到服务端中",2)
                self.network:sendToServer("server_saveData",self.effectTableData)
            end
        end
        self.lastState = false
    end
end

function MAG.client_canInteract(self,character)
	--print(self.savedState)
	sm.gui.setInteractionText( sm.gui.getKeyBinding( "Use" ).." : current applique 当前贴图 : "..self.effectList[self.currentEffectId].."  //  "..(sm.gui.getKeyBinding( "Tinker" )).." : rotate 旋转")
	return true
end

function MAG.client_onInteract(self,character,state)
    if not state then return end
    --[[if character:isCrouching() then
        self.currentEffectId = (self.currentEffectId+self.maxEffectId-2)%self.maxEffectId+1
    else
        self.currentEffectId = (self.currentEffectId)%self.maxEffectId+1
    end]]--
    --print(self.currentEffectId)

    self:findEfctPlyr()
    self.gui = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/MAG_int.layout")
    self.gui:setText("Name", " MAG ")
    self.gui:setText("SubTitle", self.effectPlayer[self.currentEfctPlyr].." : "..self.effectList[self.currentEffectId])
    self.gui:createHorizontalSlider("belongingPlayer",#self.effectPlayer-1,self.currentEffectId-1,"client_onSliderChangePlayer")
    self.gui:createHorizontalSlider("belongingPlayer2",10,self.currentEfctPlus,"client_onSliderChangeApplique")
    --self.effectList[self.currentEffectId]
    --self.gui:setSliderData("belongingPlayer", #self.effectList, self.currentEffectId-1)
    self.gui:setOnCloseCallback("client_onClose")
    self.gui:open()
end

function MAG.client_onTinker(self,character,state)
    if not state then return end
    if character:isCrouching() then
        self.currentRotation = (self.currentRotation+3)%4
    else
        self.currentRotation = (self.currentRotation+1)%4
    end
    self:changeCurrentEffect()
end

function MAG.client_onSliderChangePlayer(self, sliderPos)
    --print("P",sliderPos)
    self.currentEfctPlyr = sliderPos+1
    self.currentEfctPlus = 0
    self.currentEffectId = self.efctPlyrCnt[self.currentEfctPlyr]+self.currentEfctPlus
    --self.gui:setSliderData("belongingPlayer2",self.efctPlyrCnt[self.currentEfctPlyr+1]-self.efctPlyrCnt[self.currentEfctPlyr]+1,0)
    self.gui:setText("SubTitle", self.effectPlayer[self.currentEfctPlyr].." : "..self.effectList[self.currentEffectId])
end

function MAG.client_onSliderChangeApplique(self, sliderPos)
    --print("A",sliderPos)
    if sliderPos >= self.efctPlyrCnt[self.currentEfctPlyr+1]-self.efctPlyrCnt[self.currentEfctPlyr]  then
        self.currentEfctPlus = self.efctPlyrCnt[self.currentEfctPlyr+1]-self.efctPlyrCnt[self.currentEfctPlyr] - 1
    else
        self.currentEfctPlus = sliderPos
    end
    
    self.currentEffectId = self.efctPlyrCnt[self.currentEfctPlyr]+self.currentEfctPlus
    self.gui:setText("SubTitle", self.effectPlayer[self.currentEfctPlyr].." : "..self.effectList[self.currentEffectId])
end

function MAG.client_onClose(self)
    if self.gui then
        self.gui:close()
        self.gui:destroy()
        self.gui = nil
    end
    self:changeCurrentEffect()
end