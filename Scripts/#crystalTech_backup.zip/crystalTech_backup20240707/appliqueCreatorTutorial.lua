-- MAXZ666 --
-- Max's applique creator tutorial!
MACT = class(nil)

function MACT.client_onCreate(self)
    self.currentLanguage = sm.gui.getCurrentLanguage()
    if self.currentLanguage ~= "Chinese" and self.currentLanguage ~= "English" then
        self.currentLanguage = "English"
    end
    self.lines = {
        Chinese = {
            "查看自定义贴花装置使用教程",
            "-1- 自定义贴花装置",
            "B站教程：~ \n 自由贴贴花、自定义贴花。",
            "-2-方向要求",
            "#fcfcfc玩家面向太阳这面安装\n也就是装置处在背阳的阴影处\n这只需要在要贴贴花时遵守，否则方向是歪的",
            "-3- 激活贴花编辑",
            "#fcfcfc接入非红色信号并启动来激活装置",
            "-4- 按E改贴花造型",
            " 1-显示贴花类别和名称 \n 2-切换类别 \n 3-切换贴花 ：\n  #fcfcfc  --MaxZ666 : 我的图标\n#fcfcfc  --Content : 一些装饰用文字\n#ffe100  --Shape : 基本图形，用于自定义贴花！\n#00ffbc  --Saved保存的图 : 保存的自定义贴花",
            "-5- 按U改旋转和大小",
            " 1-绕法线旋转的角度 \n 2-大小对应X、Y、Z",
            "-6- 改贴花颜色",
            " 当前贴花的颜色由贴花装置自己的颜色提供",
            "-7- !!粘贴花",
            " 土豆枪或任意枪械瞄准（右键）时黏贴 \n 蹲下再右键是删除（蹲下时会有小箭头显示所选贴花）",
            "-8- 自定义贴花系统",
            "在任意背阳面完成自定义贴花，红色输入信号启动文件管理 \n 贴花中心会重新计算，所以只需要遵守方向是背阳面即可 \n 贴花选到最后一项就可以选你的自定义贴花了 \n 1-文件名 \n 2-已存在的文件 \n 3-打开所选文件、新建空文件、保存当前文件"
            
        },
        English = {
            "check custom applique device tutorial",
            "-1- Max's Custom Applique Device",
            "VideoTutorial : ~ \n  You can not only use some given appliques but also CUSTOMIZED your own APPLIQUE!!\nand also save it to use of course\nYou can also SHARE your applique to others by blueprint!\nOthers can download and save your applique by this device in your blueprint!",
            "-2- Device's direction demands",
            "#fcfcfcplace it where you face the sun\nwhich is the face in the shady spot\nYou need to comply with this demand only when you're pasting applique!",
            "-3- Activate",
            "#fcfcfcnonRedInput can activate this device",
            "-4- Press E to change the shape of the applique",
            "Press E to change the shape of the applique 1-show its type and name \n 2-switch type \n 3-switch applique ：\n  #fcfcfc  --MaxZ666 : My Icons\n#fcfcfc  --Context : some decorating contexts\n#ffe100  --Shape : basic shapes that you use to customize your applique\n#00ffbc  --Saved保存的图 : saved customized applique",
            "-5- Press U(Upgrade) to change the rotation and scale",
            " 1-rotate \n 2-scaleSettings:X,Y,Z",
            "-6- Change current applique's color",
            " current applique's colors depends on device's color ",
            "-7- !!Paste applique!",
            " Aim with potatoGun (right click) can paste applique \n #ff5c5fwith crouching can delete applique \n (there'll be an arrow to point out the applique to be deleted)#fcfcfc",
            "-8- Custom Applique System",
            "Red input can activate the #e0cbffCustom Applique System#fcfcfc \n SAVE can save current appliques as a customized applique \n You can put your appliques in any where \n because it'll recauculate the center position \n choose the last type of appliques to use your costumized applique \n 1-file name \n 2-existed files \n 3-Open selected file、new empty file、save current file"
        }
    }

    self.book = {
        page = 1,
        titlesN = {
            2,4,6,8,10,12,14,16
        },
        scriptsN = {
            3,5,7,9,11,13,15,17
        },
        images = {
            "0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png"
        },
        titles = {},
        scripts = {}
    }
    for k,v in pairs(self.book.titlesN)do
        self.book.titles[k] = self.lines[self.currentLanguage][v]
    end
    for k,v in pairs(self.book.scriptsN)do
        self.book.scripts[k] = self.lines[self.currentLanguage][v]
    end
end

function MACT.client_onInteract(self,character,state)
	if state then
        local maxPage = #self.book.titles
		self.gui = sm.gui.createGuiFromLayout('$MOD_DATA/Gui/Layouts/MAGtutorial.layout')
        self.gui:createDropDown("List","cl_onDropDownInteract",self.book.titles)
        self.gui:setButtonCallback("UpButton","cl_onUpMAC")
        self.gui:setButtonCallback("DownButton","cl_onDownMAC")
        self:refreshPage()
        self.gui:setOnCloseCallback("client_onClose")
		self.gui:open()
	end
end

function MACT.findPage(self , title)
    for k,v in pairs(self.book.titles)do
        if title == v then
            return k
        end
    end
    return 1
end

function MACT.refreshPage(self)
    local maxPage = #self.book.titles
    self.gui:setText("Title",self.book.titles[self.book.page])
    self.gui:setText("Description",self.book.scripts[self.book.page])
    self.gui:setSelectedDropDownItem("List", self.book.titles[self.book.page])
    self.gui:setImage("Tutorial","$MOD_DATA/Gui/Layouts/MACT/"..self.book.images[self.book.page])
    self.gui:setText("UpButton","UP - "..(self.book.page + maxPage-2)%maxPage+1)
    self.gui:setText("DownButton","DOWN - "..self.book.page%maxPage+1)
end

function MACT.cl_onDropDownInteract(self,DDname)
    self.book.page = self:findPage(DDname)
    self:refreshPage()
end

function MACT.cl_onUpMAC(self)
    local maxPage = #self.book.titles
    self.book.page = (self.book.page + maxPage-2)%maxPage+1
    self:refreshPage()
end

function MACT.cl_onDownMAC(self)
    local maxPage = #self.book.titles
    self.book.page = self.book.page%maxPage+1
    self:refreshPage()
end

function MACT.client_onClose(self)
    if self.gui then
        self.gui:close()
        self.gui:destroy()
        self.gui = nil
    end
end

function MACT.client_canInteract(self)
	sm.gui.setInteractionText("",sm.gui.getKeyBinding("Use"),self.lines[self.currentLanguage][1])
	return true
end