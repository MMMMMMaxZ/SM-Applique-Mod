localPlayer = class(nil)

localPlayer.state = {
    left = false,
    right = false,
    q = false,
    r = false
}

localPlayer.tool = "Null"

function localPlayer.reset(self)
    self.state = {
        left = false,
        right = false,
        q = false,
        r = false
    }
    self.tool = "Null"
end