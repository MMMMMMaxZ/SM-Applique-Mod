-- MAXZ666 --
-- Max's applique creator
MAC = class(nil)
MAC.maxParentCount = 1
MAC.connectionInput = sm.interactable.connectionType.logic+sm.interactable.connectionType.power

MAC.colorNormal = sm.color.new(0x14514ff)
MAC.colorHighlight = sm.color.new(0x114514aa)

MAC.effectPlayer = {}
MAC.efctPlyrCnt = {}
MAC.effectList = {}
MAC.effectUUIDList = {}

MAC.colorRed = "d02525ff"

function MAC.sortTable(self,input)
    local oup = {}
    for k,v in pairs(input)do
        local s = tonumber(string.sub(v,1,3))
        oup[s] = v
    end
    return oup
end

function MAC.create_aplq(self)
    local MACs = sm.json.open("$MOD_DATA/Scripts/MAG_list/MAGs.json")
    local orderedMACs = {}
    local cnt = 0
    for type,names in pairs(MACs)do
        cnt = cnt + 1
        orderedMACs[cnt]=type
    end
    orderedMACs = self:sortTable(orderedMACs)
    cnt = 0
    self.efctPlyrCnt[1]=1
    for i,oType in pairs(orderedMACs)do
        local type = oType
        local names = MACs[type]
        cnt = cnt + 1
        self.effectPlayer[cnt]=type
        self.efctPlyrCnt[cnt+1]=#names + self.efctPlyrCnt[cnt]
        
        --generate renderable
        for k,v in pairs(names)do
            self.effectList[self.efctPlyrCnt[cnt]+k-1]=v
            local tempRenderable = {lodList={}}
            tempRenderable["lodList"][1]={
                mesh = "$MOD_DATA/Objects/Mesh/MAG/testEftFixed.obj",
                minViewSize = 15,
                subMeshList = {
                    {
                        custom = {
                            shadow = false
                        },
                        material = "Leaves",
                        textureList = {
                            "$MOD_DATA/Objects/Textures/MAG/_empty-export.tga",
                            "$MOD_DATA/Objects/Textures/MAG/"..type.."/"..v.."_asg-export.tga",
                            "$MOD_DATA/Objects/Textures/MAG/_empty-nor.tga"
                        }
                    }
                }
            }
            if type == "000MaxZ666" then
                tempRenderable["lodList"][1]["subMeshList"][1]["textureList"][1]="$MOD_DATA/Objects/Textures/MAG/MaxZ666_dif.tga"
            end
            --sm.json.save(tempRenderable,"$MOD_DATA/Objects/Renderable/MAG/"..type.."/"..v.."_gn.rend")
        end
        
        --generate shape set
        local tempTable = {partList = {}}
        for k,v in pairs(names)do
            local a=(k-k%100)/100%10
            local b=(k-k%10)/10%10
            local c=k%10
            local ca=(cnt-cnt%100)/100%10
            local cb=(cnt-cnt%10)/10%10
            local cc=cnt%10
            tempTable["partList"][k]={
                box={
                    x=1,
                    y=1,
                    z=1
                },
                color = "FFFFFF",
                name = v,
                physicsMaterial = "Default",
                renderable = "$MOD_DATA/Objects/Renderable/MAG/"..type.."/"..v.."_gn.rend",
                rotationSet = "Default",
                showInInventory = true,
                uuid = ca..cb..cc.."2359a-1068-4de7-b7a0-a41682e47"..a..b..c
            } 

            self.effectUUIDList[self.efctPlyrCnt[cnt]+k-1]=sm.uuid.new(ca..cb..cc.."2359a-1068-4de7-b7a0-a41682e47"..a..b..c)
        end
        --sm.json.save(tempTable,"$MOD_DATA/Objects/Database/ShapeSets/MAG_"..type.."_gn.json")
    end
    local MACfiles = {"fileOperator"}
    cnt = cnt + 1
    self.effectPlayer[cnt]="Saved保存的图"
    for k,v in pairs(MACfiles)do
        self.effectList[self.efctPlyrCnt[cnt]+k-1]=v
    end
    self.efctPlyrCnt[cnt+1]=self.efctPlyrCnt[cnt]+#MACfiles
    cnt = cnt + 1
    self.effectPlayer[cnt]="End"
    self.effectList[self.efctPlyrCnt[cnt]]="lazer"
end

--server
function MAC.server_onCreate(self)
    self.Server_effectTable = self.storage:load()
    if(self.Server_effectTable==nil)then
        self.Server_effectTable={}
    end
    self.Server_tableCnt = #self.Server_effectTable
    self.Server_lastInput = false
    self.network:sendToClients("client_getSavedData",self.Server_effectTable)
end

function MAC.server_onFixedUpdate(self,dt)
    self.sv_input = self.interactable:getSingleParent()
    if self.sv_input ~= nil then
        self.sv_inputActive = self.sv_input:isActive()
    else
        self.sv_inputActive = false
    end
    if self.sv_inputActive then
        if tostring(self.sv_input.shape.color) == self.colorRed then
            self.interactable:setActive(false)
            if not self.Server_lastInput then
                local allPlayers = sm.player.getAllPlayers()
                local nPlayer = NearestPlayer(self.shape.worldPosition,allPlayers)
                self.network:sendToClient(nPlayer,"client_onFileOperate")
            end
        else
            self.interactable:setActive(true)
        end
    else 
        self.interactable:setActive(false)
    end
    self.Server_lastInput = self.sv_inputActive
end

function MAC.server_saveData(self,data)
    self.Server_effectTable = {}
    local i=1
    for idx,data in pairs(data)do
        if not data.cleanFlag then
            self.Server_effectTable[i] = data
            i = i + 1
        end
    end
    self.storage:save(self.Server_effectTable)
    self.network:sendToClients("client_getSavedData",self.Server_effectTable)
end

function NearestPlayer(position , playerList)
	local distance  = nil
	local oupPlayer = nil
	for k,v in pairs(playerList)do
		local vD = sm.vec3.length2(position - v.character.worldPosition)
		if distance == nil or vD<distance then
			distance = vD
			oupPlayer = v
		end
	end
	return oupPlayer
end

--------------------------------------------client-----------------------------------------

function MAC.client_onCreate(self)
    if localPlayer == nil then
        dofile("$MOD_DATA/Scripts/crystalTech/_localPlayer.lua")
    end

    self:create_aplq()
    self.effectTableData = {}
    self.effectTable = {}
    self.tableCnt = 0

    self.currentScale = {x=10,y=10,z=10}
    self.currentRotation = 36
    self.currentEffectId = 1
    self.maxEffectId = #self.effectList
    self.currentEfctPlyr = 1
    self.currentEfctPlus = 0

    self.localPlayer = sm.localPlayer.getPlayer()
    self.ready = true
    self.lastState = false -- false未启动，true启动

    self.scaleTable = {
        0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,
        1,1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,
        2,2.1,2.2,2.3,2.4,2.5,2.6,2.7,2.8,2.9,
        3,3.1,3.2,3.3,3.4,3.5,3.6,3.7,3.8,3.9,
        4,4.1,4.2,4.3,4.4,4.5,4.6,4.7,4.8,4.9,
        5
    }--0.255
    self.rotaTable = { 5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100,105,110,115,120,125,130,135,140,145,150,155,160,165,170,175,180,185,190,195,200,205,210,215,220,225,230,235,240,245,250,255,260,265,270,275,280,285,290,295,300,305,310,315,320,325,330,335,340,345,350,355,360 }
    self.rotaTable[0]=0

    self.currentEffect = sm.effect.createEffect("ShapeRenderable",self.interactable)
    self.currentEffect:setParameter("uuid",self.effectUUIDList[1])

    self.pointEffect = sm.effect.createEffect("point",self.interactable)

    self.fileName = "Name"

    self.MACfiles = sm.json.open("$MOD_DATA/Appliques/__List.json")
    self.selectedMAC = "Null"

    self.colorList = {"eeeeeeff", "222222ff", "d02525ff", "df7f00ff", "e2db13ff", "19e753ff", "0a3ee2ff", "7514edff", "cf11d2ff"}
    
    self.chosenColorIdx = 1

    self.currentLanguage = sm.gui.getCurrentLanguage()
    if self.currentLanguage ~= "Chinese" and self.currentLanguage ~= "English" then
        self.currentLanguage = "English"
    end
    self.lines = {
        Chinese = {
            "同步数据到服务端中",
            "旋转 ",
            " 大小 ",
            "MACFileSystem",
            "文件不存在！",
            "文件导入成功！",
            "警告",
            "文件已存在，是否覆盖？",
            "文件保存成功！",
            "超出极限300，请另用另一个贴花装置",
            "最近的颜色"
        },
        English = {
            "sending data to server",
            "rotation ",
            " scaleXYZ ",
            "MAC file system",
            "File doesn't exist!",
            "File loaded successfully!",
            "WARNING",
            "File existed! Still save?",
            "File saved successfully!",
            "Over the limit of 300, please use another applique device",
            "recent colors"
        }
    }
end

function MAC.client_getSavedData(self,savedTable)
    self.effectTableData = savedTable
    self:translateData(self.effectTableData)
    self.tableCnt = #self.effectTableData + 1
    self.nearestEffectID = nil
end

function MAC.translateData(self,inputData)
    for k,v in pairs(self.effectTable)do
        v:destroy()
        self.effectTable[k]=nil
    end
    for idx,data in pairs(inputData)do
        self.effectTable[idx] = sm.effect.createEffect("ShapeRenderable",self.interactable)
        self.effectTable[idx]:setParameter("uuid",self.effectUUIDList[data.id])
        self.effectTable[idx]:setOffsetPosition(sm.vec3.new(data.offsetPosition.x,data.offsetPosition.y,data.offsetPosition.z))
        self.effectTable[idx]:setOffsetRotation(sm.quat.new(data.offsetRotation.x,data.offsetRotation.y,data.offsetRotation.z,data.offsetRotation.w))
        self.effectTable[idx]:setParameter("color",sm.color.new(data.color))
        self.effectTable[idx]:setScale(sm.vec3.new(data.scale.x,data.scale.y,data.scale.z)*0.255)
        self.effectTable[idx]:start()
    end
end

function MAC.changeCurrentEffect(self)
    self.currentEffect:destroy()
    self:findEfctPlyr()
    if self.effectPlayer[self.currentEfctPlyr] ~= "Saved保存的图" then
        self.currentEffect = sm.effect.createEffect("ShapeRenderable",self.interactable)
        self.currentEffect:setScale(sm.vec3.new(self.scaleTable[self.currentScale.x],self.scaleTable[self.currentScale.y],self.scaleTable[self.currentScale.z])*0.255)
        self.currentEffect:setParameter("uuid",self.effectUUIDList[self.currentEffectId])
    else
        self.currentEffect = sm.effect.createEffect("ShapeRenderable",self.interactable)
        self.currentEffect:setScale(sm.vec3.new(self.scaleTable[self.currentScale.x],self.scaleTable[self.currentScale.y],self.scaleTable[self.currentScale.z])*0.255)
        self.currentEffect:setParameter("uuid",self.effectUUIDList[1])
        if self.selectedMAC == "Null" then
            self:cl_cleanCurrentMAC()
        else
            if self.selectedMACEfct == nil then
                self.selectedMACData = sm.json.open("$MOD_DATA/Appliques/"..self.selectedMAC..".json")
                self.selectedMACEfct = {}
                for k,v in pairs(self.selectedMACData)do
                    self.selectedMACEfct[k] = sm.effect.createEffect("ShapeRenderable",self.interactable)
                    self.selectedMACEfct[k]:setParameter("uuid",self.effectUUIDList[v.id])
                    self.selectedMACEfct[k]:start()
                end
            end
        end
    end
    self.currentEffect:setOffsetPosition(self.shape.up*0.3)
    self.currentEffect:start()
end

function MAC.findEfctPlyr(self)
    local oup
    for k,v in pairs(self.efctPlyrCnt)do
        if self.currentEffectId >=v and self.currentEffectId <self.efctPlyrCnt[k+1] then
            oup = k
        end
    end
    self.currentEfctPlyr = oup
    self.currentEfctPlus = self.currentEffectId - self.efctPlyrCnt[self.currentEfctPlyr]
end

function MAC.client_onFixedUpdate(self,dt)
    if self.shape.body:isOnLift() then
        for idx,efct in pairs(self.effectTable)do
            if not efct:isPlaying() and not self.effectTableData[idx].cleanFlag then
                efct:start()
            end
        end
    end

    if self.interactable:isActive()then
        if self.lastState == false then --第一次启动获取最近玩家并绑定
            localPlayer:reset()
            self.lastState = true
            local allPlayers = sm.player.getAllPlayers()
            self.currentPlayer = NearestPlayer(self.shape.worldPosition,allPlayers)
            self.currentCharacter = self.currentPlayer.character
            self.currentEffect:start()
        end
        if self.localPlayer == self.currentPlayer then 
            --开始客户端的贴花编辑！
            local putOn_condition = localPlayer.state.left   --self.currentCharacter:isAiming()
            local erase_condition = localPlayer.state.right  --self.currentCharacter:isCrouching()
            local change_condition = localPlayer.state.r
            local modify_condition = localPlayer.state.q
            local toolMode = localPlayer.tool

            local get,result = sm.localPlayer.getRaycast(10)
            if get then
                local hitLocation = result.pointWorld
                local hitNormal = result.normalWorld

                local nhitN = hitNormal:normalize()
                local nAt = self.shape.at:normalize()
                local cosK = sm.vec3.dot(nAt,nhitN)
                local KStandard = -1 -- represent the front side
                local errorRange = 0.01
                if cosK-KStandard <= errorRange then
                    hitNormal = self.shape.at*-1
                end

                local offR = sm.vec3.getRotation(self.shape.at,hitNormal)
                local fixRotation = sm.quat.inverse(self.shape.worldRotation)
                local offP = fixRotation*(hitLocation-self.shape.worldPosition)

                local efctUp = offR*self.shape.up
                local efctAt = offR*self.shape.at
                local efctRotaUp = efctUp:rotate(self.rotaTable[self.currentRotation]/180*3.14,efctAt)
                local efctRota = sm.vec3.getRotation(efctUp,efctRotaUp)
                offR = efctRota*offR

                ----删除的箭头
                if erase_condition then
                    local nIdx,nDistance = 1,1000
                    for idx,data in pairs(self.effectTableData)do
                        if not data.cleanFlag then
                            local ofp = offP - sm.vec3.new(data.offsetPosition.x,data.offsetPosition.y,data.offsetPosition.z)
                            local ofpd = ofp:length()
                            if ofpd <= nDistance then
                                nDistance = ofpd
                                nIdx = idx
                            end
                        end
                    end
                    if(nDistance<=0.23)then
                        if self.nearestEffectID ~= nIdx and self.nearestEffectID ~= nil and self.effectTable[self.nearestEffectID]:isPlaying() then
                            local PoffP = self.effectTableData[self.nearestEffectID].offsetPosition
                            self.effectTable[self.nearestEffectID]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z))
                        end
                        self.nearestEffectID = nIdx
                        local PoffP = self.effectTableData[nIdx].offsetPosition
                        local PoffR = self.effectTableData[nIdx].offsetRotation
                        self.pointEffect:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z))
                        self.pointEffect:setOffsetRotation(sm.quat.new(PoffR.x,PoffR.y,PoffR.z,PoffR.w))
                        self.effectTable[nIdx]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z)+hitNormal*0.05)
                        if not self.pointEffect:isPlaying() then self.pointEffect:start() end
                        if self.currentEffect:isPlaying() then self.currentEffect:stop() end
                    else
                        if self.pointEffect:isPlaying() then self.pointEffect:stop() end
                        if not self.currentEffect:isPlaying() then self.currentEffect:start() end
                        if self.nearestEffectID ~= nil and self.effectTable[self.nearestEffectID]:isPlaying() then
                            local PoffP = self.effectTableData[self.nearestEffectID].offsetPosition
                            self.effectTable[self.nearestEffectID]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z))
                            self.nearestEffectID = nil
                        end
                    end
                else
                    if self.pointEffect:isPlaying() then self.pointEffect:stop() end
                    if not self.currentEffect:isPlaying() then self.currentEffect:start() end
                    if self.nearestEffectID ~= nil and self.effectTable[self.nearestEffectID]:isPlaying() then
                        local PoffP = self.effectTableData[self.nearestEffectID].offsetPosition
                        self.effectTable[self.nearestEffectID]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z))
                        self.nearestEffectID = nil
                    end
                end
                ----贴上 or 删除
                if not putOn_condition then
                    self.ready = true
                    self.currentEffect:setOffsetPosition(offP)
                    self.currentEffect:setOffsetRotation(offR)
                    self.currentEffect:setScale(sm.vec3.new(self.scaleTable[self.currentScale.x],self.scaleTable[self.currentScale.y],self.scaleTable[self.currentScale.z])*0.255)
                    if self.effectPlayer[self.currentEfctPlyr] ~= "Saved保存的图" then
                        self.currentEffect:setParameter("color",sm.color.new(self.colorList[self.chosenColorIdx]))
                    elseif self.selectedMAC ~= "Null" and self.selectedMACData ~= nil then
                        for k,v in pairs(self.selectedMACData)do
                            local scaleV = sm.vec3.new(self.scaleTable[self.currentScale.x],self.scaleTable[self.currentScale.y],self.scaleTable[self.currentScale.z])
                            local originVoffP = sm.vec3.new(v.offsetPosition.x,v.offsetPosition.y,v.offsetPosition.z)*scaleV
                            local originVoffR = sm.quat.new(v.offsetRotation.x,v.offsetRotation.y,v.offsetRotation.z,v.offsetRotation.w)
                            local originVscale = sm.vec3.new(v.scale.x,v.scale.y,v.scale.z)*scaleV
                            local fixedOffR = sm.quat.inverse(sm.quat.new(0,1,0,0))
                            local VoffP = offP+offR*fixedOffR*originVoffP+hitNormal*0.01
                            local VoffR = offR*originVoffR*fixedOffR

                            self.selectedMACEfct[k]:setParameter("color",sm.color.new(v.color))
                            self.selectedMACEfct[k]:setScale(originVscale*0.255)
                            self.selectedMACEfct[k]:setOffsetPosition(VoffP)
                            self.selectedMACEfct[k]:setOffsetRotation(VoffR)
                        end
                    end
                elseif self.ready and toolMode == "MAGgun" then
                    if not erase_condition then--put
                        self.ready = false
                        if self.effectPlayer[self.currentEfctPlyr] ~= "Saved保存的图" then
                            if self:cl_checkOverSized(1) then -- not oversized
                                local scaleV = sm.vec3.new(self.scaleTable[self.currentScale.x],self.scaleTable[self.currentScale.y],self.scaleTable[self.currentScale.z])
                                self:cl_addEffect(self.currentEffectId,offP,offR,sm.color.new(self.colorList[self.chosenColorIdx]),scaleV,false)
                            end
                        else
                            if self.selectedMAC == "Null" then
                               self:createMACselectGUI()
                            else
                                local loadedMAC = self.selectedMACData
                                if loadedMAC ~= nil and self:cl_checkOverSized(#loadedMAC) then
                                    for k,v in pairs(loadedMAC)do
                                        local scaleV = sm.vec3.new(self.scaleTable[self.currentScale.x],self.scaleTable[self.currentScale.y],self.scaleTable[self.currentScale.z])
                                        local originVoffP = sm.vec3.new(v.offsetPosition.x,v.offsetPosition.y,v.offsetPosition.z)*scaleV
                                        local originVoffR = sm.quat.new(v.offsetRotation.x,v.offsetRotation.y,v.offsetRotation.z,v.offsetRotation.w)
                                        local originVscale = sm.vec3.new(v.scale.x,v.scale.y,v.scale.z)*scaleV
                                        local fixedOffR = sm.quat.inverse(sm.quat.new(0,1,0,0))
                                        local VoffP = offP+offR*fixedOffR*originVoffP+hitNormal*0.01
                                        local VoffR = offR*originVoffR*fixedOffR

                                        self:cl_addEffect(v.id,VoffP,VoffR,sm.color.new(v.color),originVscale,v.cleanFlag)
                                    end
                                end
                            end
                        end
                    elseif #self.effectTableData > 0 and self.ready and self.nearestEffectID ~= nil then --erase
                        self.ready = false
                        local nIdx = self.nearestEffectID
                        self.effectTableData[nIdx].cleanFlag = true
                        self.effectTable[nIdx]:stop()
                    end
                elseif self.ready and toolMode == "MAGpainter" then
                    local hitShape = result:getShape()
                    if hitShape ~= nil then
                        local hitColor = hitShape.color:getHexStr()
                        for k = 9,2,-1 do
                            self.colorList[k]= self.colorList[k-1]
                        end
                        self.colorList[1] = hitColor
                    end
                end
            end
            --切换 特效种类
            if change_condition then
                self:client_onInteract(self.localPlayer.character,true)
            end
            --设置 旋转和大小
            --clear localPlayer state
            if modify_condition then
                self:client_onTinker(self.localPlayer.character,true)
            end
            localPlayer:reset()
        end
    else
        if self.lastState == true then
            if self.localPlayer == self.currentPlayer then 
                self.currentEffect:stop()
                self:cl_cleanCurrentMAC()
                --send back data
                sm.gui.displayAlertText(self.lines[self.currentLanguage][1],2)
                self.network:sendToServer("server_saveData",self.effectTableData)
            end
        end
        self.lastState = false
    end
end

function MAC.cl_cleanCurrentMAC(self)
    if self.selectedMACEfct~=nil then
        for k,v in pairs(self.selectedMACEfct)do
            v:destroy()
        end
        self.selectedMACEfct = nil
    end
    self.selectedMAC = "Null"
    self.selectedMACData = nil
end

function MAC.cl_checkOverSized(self,addT)
    local limit = 270
    if #self.effectTableData + addT > limit then
        sm.gui.displayAlertText(self.lines[self.currentLanguage][10])
        return false
    else
        return true
    end
end

function MAC.cl_addEffect(self,id,offP,offR,color,scale,cleanFlag)
    self.effectTable[self.tableCnt]=sm.effect.createEffect("ShapeRenderable",self.interactable)
    self.effectTable[self.tableCnt]:setParameter("uuid",self.effectUUIDList[id])
    self.effectTable[self.tableCnt]:setParameter("color",color)
    self.effectTable[self.tableCnt]:setScale(scale*0.255)
    self.effectTable[self.tableCnt]:setOffsetPosition(offP)
    self.effectTable[self.tableCnt]:setOffsetRotation(offR)
    self.effectTable[self.tableCnt]:start()
    self.effectTableData[self.tableCnt]={
        id = id ,
        offsetPosition = {x=offP.x,y=offP.y,z=offP.z},
        offsetRotation = {x=offR.x,y=offR.y,z=offR.z,w=offR.w},
        color = color:getHexStr(),
        scale = {x=scale.x,y=scale.y,z=scale.z},
        cleanFlag = cleanFlag
    }
    self.tableCnt = self.tableCnt + 1

end

function MAC.client_canInteract(self,character)
	--sm.gui.setInteractionText( sm.gui.getKeyBinding( "Use" ).." : current applique 当前贴图 : "..self.effectList[self.currentEffectId].."  //  "..(sm.gui.getKeyBinding( "Tinker" )).." : rotate 旋转")
	return true
end

function MAC.client_onInteract(self,character,state)
    if not state then return end
    self:cl_cleanCurrentMAC()
    self:findEfctPlyr()
    self.gui = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/MAG_int.layout")
    self.gui:setText("Name", " MAG ")
    self.gui:setText("SubTitle", self.effectPlayer[self.currentEfctPlyr].." : "..self.effectList[self.currentEffectId])
    self.gui:createHorizontalSlider("slider1",#self.effectPlayer-1,self.currentEfctPlyr-1,"client_onSliderChangePlayer",true)
    self.gui:createHorizontalSlider("slider2",20,self.currentEfctPlus,"client_onSliderChangeApplique",true)
    self.gui:setImage("Tutorial","$MOD_DATA/Gui/Layouts/black.png")
    self.gui:setOnCloseCallback("client_onClose")
    self.gui:open()
end

function MAC.client_canTinker(self,character)
    if not self.shape.usable then
		return false
	end
    return true
end

function MAC.client_onTinker(self,character,state)
    if not state then return end
    self.gui = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/MAG_rota_scale_color.layout")
    self.gui:setText("Name", "Rotation and Scale")
    self.gui:setText("SubTitle", self.lines[self.currentLanguage][2]..self.rotaTable[self.currentRotation]..self.lines[self.currentLanguage][3]..self.scaleTable[self.currentScale.x]..","..self.scaleTable[self.currentScale.y]..","..self.scaleTable[self.currentScale.z])
    self.gui:setText("colorText",self.lines[self.currentLanguage][11])
    self.gui:setImage("Tutorial","$MOD_DATA/Gui/Layouts/black.png")

    self.gui:createHorizontalSlider("slider1",#self.rotaTable-1,self.currentRotation,"client_onSliderChangeOffRota",false)
    self.gui:createHorizontalSlider("slider2",#self.scaleTable,self.currentScale.x-1,"client_onSliderChangeScaleX",false)
    self.gui:createHorizontalSlider("slider3",#self.scaleTable,self.currentScale.y-1,"client_onSliderChangeScaleY",false)
    self.gui:createHorizontalSlider("slider4",#self.scaleTable,self.currentScale.z-1,"client_onSliderChangeScaleZ",false)
    
    for k=1, 9 do
        self.gui:setImage("EmptyColorA" .. tostring(k),"$MOD_DATA/Gui/Layouts/emptyColor.png")
        self.gui:setColor("emptyColorA" .. tostring(k),sm.color.new(self.colorList[k]))
        self.gui:setButtonCallback( "colorB" .. tostring(k), "cl_chooseColor" ) 
    end

    self.gui:setOnCloseCallback("client_onClose")
    self.gui:open()
end

function MAC.client_onFileOperate(self)
    if self.gui ~= nil then return end
    self.MACfiles = sm.json.open("$MOD_DATA/Appliques/__List.json")
    self.tempMACname = 1
    self.gui = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/MAC_int.layout" , false)
    --self.gui:setText("Name", self.lines[self.currentLanguage][4])
    self.gui:setTextChangedCallback("AppliqueName","cl_onChangeApqName")
    self.gui:setTextAcceptedCallback("AppliqueName","cl_onChangeDoneApqName")
    self.gui:setText("AppliqueName",self.fileName)
    self.gui:createDropDown("AppliqueList","cl_onDropDownInteract",self.MACfiles)
    self.gui:setSelectedDropDownItem("AppliqueList", self.MACfiles[1])
    self.gui:setButtonCallback("NewButton","cl_onNewMAC")
    self.gui:setButtonCallback("OpenButton","cl_onOpenMAC")
    self.gui:setButtonCallback("SaveButton","cl_onSaveMAC")
    self.gui:setOnCloseCallback("client_onClose")
    self.gui:open()
end

function MAC.createMACselectGUI(self)
    if self.gui ~= nil then return end
    self.MACfiles = sm.json.open("$MOD_DATA/Appliques/__List.json")
    self.tempMACname = 1
    self.gui = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/MAC_fileOpen.layout" , false)
    --self.gui:setText("Name", self.lines[self.currentLanguage][4])
    self.gui:createDropDown("AppliqueList","cl_onDropDownSelect",self.MACfiles)
    self.gui:setSelectedDropDownItem("AppliqueList", self.MACfiles[1])
    self.gui:setButtonCallback("OpenButton","cl_onOpenSelectedMAC")
    self.gui:setOnCloseCallback("client_onClose")
    self.gui:open()
end

function MAC.cl_chooseColor(self,button)
    local buttonId = tonumber(button:match("(%d+)"))
    self.chosenColorIdx = buttonId
end

function MAC.cl_onDropDownSelect(self,DDname)
    self.selectedMAC = DDname
end

function MAC.cl_onOpenSelectedMAC(self)
    self.gui:close()
end

function MAC.cl_onChangeApqName(self,editBoxName,MACname)
    self.fileName = MACname
end

function MAC.cl_onChangeDoneApqName(self,editBoxName,MACname)
    self.fileName = MACname
end

function MAC.cl_onDropDownInteract(self,DDname)
    self.fileName = DDname
    self.gui:setText("AppliqueName",self.fileName)
end

function MAC.cl_onNewMAC(self,button)
    self.network:sendToServer("server_saveData",{})
    self.effectTableData={}
end

function MAC.cl_onOpenMAC(self,button)
    if not sm.json.fileExists("$MOD_DATA/Appliques/"..self.fileName..".json") then
        sm.gui.chatMessage(self.lines[self.currentLanguage][5])
        self.effectTableData = {}
    else
        self.effectTableData = sm.json.open("$MOD_DATA/Appliques/"..self.fileName..".json")
        sm.gui.chatMessage(self.lines[self.currentLanguage][6])
    end
    self.network:sendToServer("server_saveData",self.effectTableData)
end

function MAC.isExist(self,fTable,fName)
    for k,v in pairs(fTable)do
        flag = flag or (v==fName)
    end
    return flag
end

function MAC.cl_onSaveMAC(self,button)
    if not self:isExist(self.MACfiles,self.fileName) then
        self.MACfiles[#self.MACfiles+1] = self.fileName
        self:cl_saveMAC()
    else
        self.gui:close()
        self.warningGUI = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/warning.layout",true)
        self.warningGUI:setText("Name", self.lines[self.currentLanguage][7])
        self.warningGUI:setText("SubTitle", self.lines[self.currentLanguage][8])
        self.warningGUI:setButtonCallback("No","cl_wnNo")
        self.warningGUI:setButtonCallback("Yes","cl_wnYes")
        self.warningGUI:open()
    end
end

function MAC.cl_saveMAC(self)
    local centerPosition = sm.vec3.new(0,0,0)
    if #self.effectTableData ~= 0 then
        for k,v in pairs(self.effectTableData)do
            centerPosition = centerPosition + sm.vec3.new(v.offsetPosition.x,v.offsetPosition.y,v.offsetPosition.z)
        end
        centerPosition = centerPosition/#self.effectTableData
        for k,v in pairs(self.effectTableData)do
            local VnewOffPosition = sm.vec3.new(v.offsetPosition.x,v.offsetPosition.y,v.offsetPosition.z)-centerPosition
            v.offsetPosition = {x=VnewOffPosition.x,y=VnewOffPosition.y,z=VnewOffPosition.z}
        end
    end
    sm.json.save(self.MACfiles,"$MOD_DATA/Appliques/__List.json")
    sm.json.save(self.effectTableData,"$MOD_DATA/Appliques/"..self.fileName..".json")
    sm.gui.chatMessage(self.lines[self.currentLanguage][9])
end

function MAC.cl_wnNo(self)
    self.warningGUI:close()
    self:client_onFileOperate()
end

function MAC.cl_wnYes(self)
    self:cl_saveMAC()
    self.warningGUI:close()
end

function MAC.client_onSliderChangePlayer(self, sliderPos)
    self.currentEfctPlyr = sliderPos+1
    self.currentEfctPlus = 0
    self.currentEffectId = self.efctPlyrCnt[self.currentEfctPlyr]+self.currentEfctPlus
    self.gui:setText("SubTitle", self.effectPlayer[self.currentEfctPlyr].." : "..self.effectList[self.currentEffectId])
    self:changeCurrentEffect()
end

function MAC.client_onSliderChangeApplique(self, sliderPos)
    if sliderPos >= self.efctPlyrCnt[self.currentEfctPlyr+1]-self.efctPlyrCnt[self.currentEfctPlyr]  then
        self.currentEfctPlus = self.efctPlyrCnt[self.currentEfctPlyr+1]-self.efctPlyrCnt[self.currentEfctPlyr] - 1
    else
        self.currentEfctPlus = sliderPos
    end
    
    self.currentEffectId = self.efctPlyrCnt[self.currentEfctPlyr]+self.currentEfctPlus
    self.gui:setText("SubTitle", self.effectPlayer[self.currentEfctPlyr].." : "..self.effectList[self.currentEffectId])
    self:changeCurrentEffect()
end

function MAC.client_onSliderChangeOffRota(self, sliderPos)
    self.currentRotation = sliderPos
    self.gui:setText("SubTitle", self.lines[self.currentLanguage][2]..self.rotaTable[self.currentRotation]..self.lines[self.currentLanguage][3]..self.scaleTable[self.currentScale.x]..","..self.scaleTable[self.currentScale.y]..","..self.scaleTable[self.currentScale.z])
    self:changeCurrentEffect()
end

function MAC.client_onSliderChangeScaleX(self, sliderPos)
    self.currentScale.x = sliderPos+1
    self.gui:setText("SubTitle", self.lines[self.currentLanguage][2]..self.rotaTable[self.currentRotation]..self.lines[self.currentLanguage][3]..self.scaleTable[self.currentScale.x]..","..self.scaleTable[self.currentScale.y]..","..self.scaleTable[self.currentScale.z])
    self:changeCurrentEffect()
end

function MAC.client_onSliderChangeScaleY(self, sliderPos)
    self.currentScale.y = sliderPos+1
    self.gui:setText("SubTitle", self.lines[self.currentLanguage][2]..self.rotaTable[self.currentRotation]..self.lines[self.currentLanguage][3]..self.scaleTable[self.currentScale.x]..","..self.scaleTable[self.currentScale.y]..","..self.scaleTable[self.currentScale.z])
    self:changeCurrentEffect()
end

function MAC.client_onSliderChangeScaleZ(self, sliderPos)
    self.currentScale.z = sliderPos+1
    self.gui:setText("SubTitle", self.lines[self.currentLanguage][2]..self.rotaTable[self.currentRotation]..self.lines[self.currentLanguage][3]..self.scaleTable[self.currentScale.x]..","..self.scaleTable[self.currentScale.y]..","..self.scaleTable[self.currentScale.z])
    self:changeCurrentEffect()
end

function MAC.client_onClose(self)
    if self.gui then
        self.gui:close()
        self.gui:destroy()
        self.gui = nil
    end
    self:changeCurrentEffect()
end