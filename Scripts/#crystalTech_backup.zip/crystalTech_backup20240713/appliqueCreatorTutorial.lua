-- MAXZ666 --
-- Max's applique creator tutorial!
MACT = class(nil)

function MACT.client_onCreate(self)
    self.currentLanguage = sm.gui.getCurrentLanguage()
    if self.currentLanguage ~= "Chinese" and self.currentLanguage ~= "English" then
        self.currentLanguage = "English"
    end
    self.lines = {
        Chinese = {
            "查看自定义贴花装置使用教程",
            "-1- 自定义贴花装置",
            "B站教程：https://www.bilibili.com/video/BV14M4m127RG/ \n 自由贴贴花、自定义贴花。",
            "-2-方向要求",
            "#fcfcfc玩家面向太阳这面安装\n也就是装置处在背阳的阴影处\n这只需要在要贴贴花时遵守，否则方向是歪的",
            "-3- 激活贴花编辑",
            "#fcfcfc接入非红色信号并启动来激活装置的编辑模式\n关闭来保存贴花\n平时不编辑的话不激活也是会显示贴花的哦",
            "-4- !!粘贴花",
            " #fcfcfc手持MAG贴花工具 \n #00ffbc左键#fcfcfc放置贴花\n 按住右键#fcfcfc时为删除模式，此时再#00ffbc左键#fcfcfc可以删除贴花",
            "-5- 按R改贴花造型",
            " #fcfcfc手持MAG贴花工具按#00ffbcR键（换弹键）#fcfcfc\n 1-显示贴花类别和名称 \n 2-切换类别 \n 3-切换贴花 ：\n #fcfcfc  --MaxZ666 : 我的图标\n#fcfcfc  --Content : 一些装饰用文字\n#ffe100  --Shape : 基本图形，用于自定义贴花！\n#00ffbc  --Saved保存的图 : 保存的自定义贴花\n",
            "-6- 按Q改旋转、大小和颜色",
            " #fcfcfc手持MAG贴花工具按#00ffbcQ键（旋转键）#fcfcfc\n 1-绕法线旋转的角度 \n 2-大小对应X、Y、Z",
            "-7- 改贴花颜色",
            " #fcfcfc手持MAG贴花工具\n 按#00ffbc左键#fcfcfc读取颜色\n 按#00ffbcQ键（旋转键）#fcfcfc右侧九宫格可以选择最近读取的九个颜色\n",
            "-8- 自定义贴花系统",
            "在任意背阳面完成自定义贴花，红色输入信号启动#e0cbff文件管理#fcfcfc \n 贴花中心会重新计算，所以只需要遵守方向是背阳面即可 \n 贴花选到最后一项就可以选你的自定义贴花了 \n 1-文件名 \n 2-已存在的文件 \n 3-打开所选文件、新建空文件、保存当前文件"
            
        },
        English = {
            "check custom applique device tutorial",
            "-1- Max's Custom Applique Device",
            "VideoTutorial : ~ \n  You can not only use some given appliques \n but also CUSTOMIZED your own APPLIQUE!!\n and also save it to use of course\n You can also SHARE your applique to others by blueprint!\n Others can download and save your applique \n by this device in your blueprint!",
            "-2- Device's direction demands",
            "#fcfcfcplace it where you face the sun\nwhich is the face in the shady spot\nYou need to comply with this demand \nonly when you're pasting applique!",
            "-3- Activate",
            "#fcfcfcnonRedInput can activate this device's edit mode\n turn it off can save appliques \n showing applique doesn't need to be activated",
            "-4- !!Paste applique!",
            " #fcfcfc hold MAG tool \n #00ffbcleft click#fcfcfc to put on applique \n #00ffbcholding right click#fcfcfc is erase mode,then #00ffbcleft click#fcfcfc to delete applique",
            "-5- change shape ",
            " #fcfcfc hold MAG tool \nPress R to change the shape of the applique \n 1-show its type and name \n 2-switch type \n 3-switch applique : \n  #fcfcfc  --MaxZ666 : My Icons\n#fcfcfc  --Context : some decorating contexts\n#ffe100  --Shape : basic shapes that you use to customize your applique\n#00ffbc  --Saved保存的图 : saved customized applique",
            "-6- change rotation and scale",
            " #fcfcfc hold MAG tool \n Press Q(toggle) \n 1-rotate \n 2-scaleSettings:X,Y,Z",
            "-7- change current color",
            " #fcfcfc hold MAG color reader \nleft click to scan and add color\n click the colors can change the color",
            "-8- Custom Applique System",
            "Red input can activate the #e0cbffCustom Applique System#fcfcfc \n SAVE can save current appliques as a customized applique \n You can put your appliques in any where \n because it'll recauculate the center position \n choose the last type of appliques to use your costumized applique \n 1-file name \n 2-existed files \n 3-Open selected file, new empty file, save current file"
        }
    }

    self.book = {
        page = 1,
        titlesN = {
            2,4,6,8,10,12,14,16
        },
        scriptsN = {
            3,5,7,9,11,13,15,17
        },
        images = {
            "0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png"
        },
        titles = {},
        scripts = {}
    }
    for k,v in pairs(self.book.titlesN)do
        self.book.titles[k] = self.lines[self.currentLanguage][v]
    end
    for k,v in pairs(self.book.scriptsN)do
        self.book.scripts[k] = self.lines[self.currentLanguage][v]
    end
end

function MACT.client_onInteract(self,character,state)
	if state then
        local maxPage = #self.book.titles
		self.gui = sm.gui.createGuiFromLayout('$MOD_DATA/Gui/Layouts/MAGtutorial.layout')
        self.gui:createDropDown("List","cl_onDropDownInteract",self.book.titles)
        self.gui:setButtonCallback("UpButton","cl_onUpMAC")
        self.gui:setButtonCallback("DownButton","cl_onDownMAC")
        self:refreshPage()
        self.gui:setOnCloseCallback("client_onClose")
		self.gui:open()
	end
end

function MACT.findPage(self , title)
    for k,v in pairs(self.book.titles)do
        if title == v then
            return k
        end
    end
    return 1
end

function MACT.refreshPage(self)
    local maxPage = #self.book.titles
    self.gui:setText("Title",self.book.titles[self.book.page])
    self.gui:setText("Description",self.book.scripts[self.book.page])
    self.gui:setSelectedDropDownItem("List", self.book.titles[self.book.page])
    self.gui:setImage("Tutorial","$MOD_DATA/Gui/Layouts/MACT/"..self.book.images[self.book.page])
    self.gui:setText("UpButton","UP - "..(self.book.page + maxPage-2)%maxPage+1)
    self.gui:setText("DownButton","DOWN - "..self.book.page%maxPage+1)
end

function MACT.cl_onDropDownInteract(self,DDname)
    self.book.page = self:findPage(DDname)
    self:refreshPage()
end

function MACT.cl_onUpMAC(self,button)
    local maxPage = #self.book.titles
    self.book.page = (self.book.page + maxPage-2)%maxPage+1
    self:refreshPage()
end

function MACT.cl_onDownMAC(self,button)
    local maxPage = #self.book.titles
    self.book.page = self.book.page%maxPage+1
    self:refreshPage()
end

function MACT.client_onClose(self)
    if self.gui then
        self.gui:close()
        self.gui:destroy()
        self.gui = nil
    end
end

function MACT.client_canInteract(self)
	sm.gui.setInteractionText("",sm.gui.getKeyBinding("Use"),self.lines[self.currentLanguage][1])
	return true
end