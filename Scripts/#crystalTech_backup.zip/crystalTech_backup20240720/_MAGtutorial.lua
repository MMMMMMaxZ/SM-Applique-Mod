--MAG's tutorial
MTt = class(nil)

function MTt.init(self)
    if MLines == nil then
        dofile("$MOD_DATA/Scripts/crystalTech/_MLines.lua")
        MLines:init()
    end
    self.book = {
        page = 1,
        titlesN = {
            2,4,6,8,10,12,14
        },
        scriptsN = {
            3,5,7,9,11,13,15
        },
        images = {
            "0.png","1.png","2.png","3.png","4.png","5.png","6.png"
        },
        titles = {},
        scripts = {}
    }
    for k,v in pairs(self.book.titlesN)do
        self.book.titles[k] = MLines.lines["Mtutorial"][MLines.currentLanguage][v]
    end
    for k,v in pairs(self.book.scriptsN)do
        self.book.scripts[k] = MLines.lines["Mtutorial"][MLines.currentLanguage][v]
    end
end