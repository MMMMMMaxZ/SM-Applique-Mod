-- MAXZ666
-- for lines in different languages
MLines = class(nil)

MLines.currentLanguage = nil
MLines.lines = {}
MLines.availableLans = {
    Chinese = true,
    English = true
}

function MLines.init(self)
    self.currentLanguage = sm.gui.getCurrentLanguage()
    if not self.availableLans[self.currentLanguage] then
        self.currentLanguage = "English" -- default to English 默认英文咯
    end
    self.lines = {
        Mtutorial = {
            Chinese = {
                "查看自定义贴花装置使用教程",
                "-1- 自定义贴花装置",
                "B站教程：https://www.bilibili.com/video/BV14M4m127RG/ \n 自由贴贴花、自定义贴花。",
                "-2- 激活贴花编辑",
                "#fcfcfc接入非红色信号并启动来激活装置的编辑模式\n关闭来保存贴花\n平时不编辑的话不激活也是会显示贴花的哦",
                "-3- !!粘贴花",
                " #fcfcfc手持MAG贴花工具 \n #00ffbc左键#fcfcfc放置贴花\n 按住右键#fcfcfc时为删除模式，此时再#00ffbc左键#fcfcfc可以删除贴花",
                "-4- 按R改贴花造型",
                " #fcfcfc手持MAG贴花工具按#00ffbcR键（换弹键）#fcfcfc\n 1-显示贴花类别和名称 \n 2-切换类别 \n 3-切换贴花 ：\n #fcfcfc  --MaxZ666 : 我的图标\n#fcfcfc  --Content : 一些装饰用文字\n#ffe100  --Shape : 基本图形，用于自定义贴花！\n#00ffbc  --Saved保存的图 : 保存的自定义贴花\n",
                "-5- 按Q改旋转、大小和颜色",
                " #fcfcfc手持MAG贴花工具按#00ffbcQ键（旋转键）#fcfcfc\n 1-绕法线旋转的角度 \n 2-大小对应X、Y、Z",
                "-6- 改贴花颜色",
                " #fcfcfc手持MAG贴花工具\n 按#00ffbc左键#fcfcfc读取颜色\n 按#00ffbcQ键（旋转键）#fcfcfc右侧九宫格可以选择最近读取的九个颜色\n",
                "-7- 自定义贴花系统",
                "在任意面完成自定义贴花，红色输入信号启动#e0cbff文件管理#fcfcfc \n 贴花中心会重新计算 \n 贴花选到最后一项就可以选你的自定义贴花了 \n 1-文件名 \n 2-已存在的文件 \n 3-打开所选文件、新建空文件、保存当前文件"
                
            },
            English = {
                "check custom applique device tutorial",
                "-1- Max's Custom Applique Device",
                "VideoTutorial : ~ \n  You can not only use some given appliques \n but also CUSTOMIZED your own APPLIQUE!!\n and also save it to use of course\n You can also SHARE your applique to others by blueprint!\n Others can download and save your applique \n by this device in your blueprint!",
                "-2- Activate",
                "#fcfcfcnonRedInput can activate this device's edit mode\n turn it off can save appliques \n showing applique doesn't need to be activated",
                "-3- !!Paste applique!",
                " #fcfcfc hold MAG tool \n #00ffbcleft click#fcfcfc to put on applique \n #00ffbcholding right click#fcfcfc is erase mode,then #00ffbcleft click#fcfcfc to delete applique",
                "-4- change shape ",
                " #fcfcfc hold MAG tool \nPress R to change the shape of the applique \n 1-show its type and name \n 2-switch type \n 3-switch applique : \n  #fcfcfc  --MaxZ666 : My Icons\n#fcfcfc  --Context : some decorating contexts\n#ffe100  --Shape : basic shapes that you use to customize your applique\n#00ffbc  --Saved保存的图 : saved customized applique",
                "-5- change rotation and scale",
                " #fcfcfc hold MAG tool \n Press Q(toggle) \n 1-rotate \n 2-scaleSettings:X,Y,Z",
                "-6- change current color",
                " #fcfcfc hold MAG color reader \nleft click to scan and add color\n click the colors can change the color",
                "-7- Custom Applique System",
                "Red input can activate the #e0cbffCustom Applique System#fcfcfc \n SAVE can save current appliques as a customized applique \n You can put your appliques in any where \n because it'll recauculate the center position \n choose the last type of appliques to use your costumized applique \n 1-file name \n 2-existed files \n 3-Open selected file, new empty file, save current file"
            }
        },
        Mtools = {
            Chinese = {
                "放置/删除贴花",
                "删除模式",
                "编辑旋转、大小、颜色",
                "设置贴花类型",
                "读取颜色",
                [[
    #fcfcfc
    MAG处理工具

    #00ffbc左键#fcfcfc放置贴花
    #00ffbc按住右键#fcfcfc时为删除模式
        此时再#00ffbc左键#fcfcfc可以删除贴花
    #00ffbcR#fcfcfc 切换贴花
    #00ffbcQ#fcfcfc 设置旋转、大小和颜色
                ]],
                [[
    #fcfcfc
    MAG颜色工具

    #00ffbc左键#fcfcfc添加颜色
    #00ffbcQ#fcfcfc 设置旋转、大小和颜色
                ]],
                "选择贴花",
                "取消选择",
                [[
    #fcfcfc
    MAG选择工具

    #00ffbc左键#fcfcfc选择贴花
    #00ffbc右键#fcfcfc取消选择
                ]]
            },
            English = {
                "place/erase applique",
                "erase mode",
                "edit rotation,scale,color",
                "set shape",
                "scan color",
                [[
    #fcfcfc
    MAG's operator tool!!

    #00ffbcleft click#fcfcfc to put on applique
    #00ffbcholding right click#fcfcfc is erase mode
        then #00ffbcleft click#fcfcfc to delete applique
    #00ffbcR#fcfcfc to switch applique
    #00ffbcQ#fcfcfc to set its rotation, scale and color
                ]],
                [[
    #fcfcfc
    MAG's paint tool!!

    #00ffbcleft click#fcfcfc to add color
    #00ffbcQ#fcfcfc to set its rotation, scale and color
                ]],
                "select applique",
                "cancel selection",
                [[
    #fcfcfc
    MAG select tool

    #00ffbcleft click #fcfcfcselect applique
    #00ffbcright click #fcfcfccancel selection
                ]]
            }
        },
        MAC = {
            Chinese = {
                "同步数据到服务端中",
                "旋转 ",
                " 大小 ",
                "MACFileSystem",
                "文件不存在！",
                "文件导入成功！",
                "警告",
                "文件已存在，是否覆盖？",
                "文件保存成功！",
                "超出极限300，请另用另一个贴花装置",
                "最近的颜色",
                "该贴花保存于另一个模组中，无法覆盖"
            },
            English = {
                "sending data to server",
                "rotation ",
                " scaleXYZ ",
                "MAC file system",
                "File doesn't exist!",
                "File loaded successfully!",
                "WARNING",
                "File existed! Still save?",
                "File saved successfully!",
                "Over the limit of 300, please use another applique device",
                "recent colors",
                "File existed in another Mod that cant be saved"
            }
        }
    }
end