-- MAXZ666 --
MACP = class(nil)

function MACP.init(self)
    print("MACP initiating---")

    if CE == nil then
        dofile("$MOD_DATA/Scripts/crystalTech/_createEffects.lua") -- self:create_aplq()
        CE:init()
    end

    self.currentScale = {x=10,y=10,z=10,mirror=1}
    self.currentRotation = 36
    self.currentEffectId = 1
    --self.maxEffectId = #CE.effectList -- 不知道干嘛用的，忘了，反正没有用到的地方
    self.currentEfctPlyr = 1
    self.currentEfctPlus = 0

    self.localPlayer = sm.localPlayer.getPlayer()

    self.scaleTable = {
        0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,
        1.0,1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,
        2.0,2.1,2.2,2.3,2.4,2.5,2.6,2.7,2.8,2.9,
        3.0,3.1,3.2,3.3,3.4,3.5,3.6,3.7,3.8,3.9,
        4.0,4.1,4.2,4.3,4.4,4.5,4.6,4.7,4.8,4.9,
        5.0
    }--0.255
    self.rotaTable = { 5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100,105,110,115,120,125,130,135,140,145,150,155,160,165,170,175,180,185,190,195,200,205,210,215,220,225,230,235,240,245,250,255,260,265,270,275,280,285,290,295,300,305,310,315,320,325,330,335,340,345,350,355,360 }
    self.rotaTable[0]=0

    self.alignTable = {100000,100,10,5}
    self.curAlign = 1

    self.curAplqStateTable = {origin = "glow",glow = "origin"}
    self.curAplqState = "origin" -- origin , glow

    self.fixNormalFlag = false
    self.lastNormal = sm.vec3.new(0,0,0)

    self.fileName = "Name"

    self.MACfiles = CE:getMACfiles()
    self.selectedMAC = "Null"

    self.colorList = {
        {"eeeeeeff", "f5f071ff", "cbf66fff", "68ff88ff", "7eededff", "4c6fe3ff", "ae79f0ff", "ee7bf0ff", "f06767ff", "eeaf5cff"},
        {"7f7f7fff", "e2db13ff", "a0ea00ff", "19e753ff", "2ce6e6ff", "0a3ee2ff", "7514edff", "cf11d2ff", "d02525ff", "df7f00ff"},
        {"4a4a4aff", "817c00ff", "577d07ff", "0e8031ff", "118787ff", "0f2e91ff", "500aa6ff", "720a74ff", "7c0000ff", "673b00ff"},
        {"222222ff", "323000ff", "375000ff", "064023ff", "0a4444ff", "0a1d5aff", "35086cff", "520653ff", "560202ff", "472800ff"},

        {"eeeeeeff", "eeeeeeff", "eeeeeeff", "eeeeeeff", "eeeeeeff", "eeeeeeff", "eeeeeeff", "eeeeeeff", "eeeeeeff", "eeeeeeff","eeeeeeff"}
    }

    self.currentColor = sm.color.new("000000ff")
    self.chosenColorType = 2
    self.chosenColorIdx = 1
end