-- MAXZ666
-- for lines in different languages
MLines = class(nil)

MLines.currentLanguage = nil
MLines.lines = {}
MLines.availableLans = {
    Chinese = true,
    English = true
}

function MLines.init(self)
    self.currentLanguage = sm.gui.getCurrentLanguage()
    if not self.availableLans[self.currentLanguage] then
        self.currentLanguage = "English" -- default to English 默认英文咯
    end
    self.lines = {
        Mtutorial = {
            Chinese = {
                "查看自定义贴花装置使用教程",
                "-1- 自定义贴花装置",
                "B站教程：https://www.bilibili.com/video/BV14M4m127RG/ \n 自由贴贴花、自定义贴花。",
                "-2- 激活贴花编辑",
                "#fcfcfc接入非红色信号并启动来激活装置的编辑模式\n关闭来保存贴花\n平时不编辑的话不激活也是会显示贴花的哦",
                "-3- !!粘贴花",
                " #fcfcfc手持MAG贴花工具 \n #00ffbc左键#fcfcfc放置贴花\n 按住右键#fcfcfc时为删除模式，此时再#00ffbc左键#fcfcfc可以删除贴花",
                "-4- 按R改贴花造型",
                " #fcfcfc手持MAG贴花工具按#00ffbcR键（换弹键）#fcfcfc\n 1-显示贴花类别和名称 \n 2-切换类别 \n 3-切换贴花 ：\n #fcfcfc  --MaxZ666 : 我的图标\n#fcfcfc  --Content : 一些装饰用文字\n#ffe100  --Shape : 基本图形，用于自定义贴花！\n#00ffbc  --Saved保存的图 : 保存的自定义贴花\n",
                "-5- 按Q改旋转、大小和颜色",
                " #fcfcfc手持MAG贴花工具按#00ffbcQ键（旋转键）#fcfcfc\n 1-绕法线旋转的角度 \n 2-大小对应X、Y、Z",
                "-6- 改贴花颜色",
                " #fcfcfc手持MAG贴花工具\n 按#00ffbc左键#fcfcfc读取颜色\n 按#00ffbcQ键（旋转键）#fcfcfc右侧九宫格可以选择最近读取的九个颜色\n",
                "-7- 自定义贴花系统",
                "在任意面完成自定义贴花，红色输入信号启动#e0cbff文件管理#fcfcfc \n 贴花中心会重新计算 \n 贴花选到最后一项就可以选你的自定义贴花了 \n 1-文件名 \n 2-已存在的文件 \n 3-打开所选文件、新建空文件、保存当前文件"
                
            },
            English = {
                "check custom applique device tutorial",
                "-1- Max's Custom Applique Device",
                "VideoTutorial : ~ \n  You can not only use some given appliques \n but also CUSTOMIZED your own APPLIQUE!!\n and also save it to use of course\n You can also SHARE your applique to others by blueprint!\n Others can download and save your applique \n by this device in your blueprint!",
                "-2- Activate",
                "#fcfcfcnonRedInput can activate this device's edit mode\n turn it off can save appliques \n showing applique doesn't need to be activated",
                "-3- !!Paste applique!",
                " #fcfcfc hold MAG tool \n #00ffbcleft click#fcfcfc to put on applique \n #00ffbcholding right click#fcfcfc is erase mode,then #00ffbcleft click#fcfcfc to delete applique",
                "-4- change shape ",
                " #fcfcfc hold MAG tool \nPress R to change the shape of the applique \n 1-show its type and name \n 2-switch type \n 3-switch applique : \n  #fcfcfc  --MaxZ666 : My Icons\n#fcfcfc  --Context : some decorating contexts\n#ffe100  --Shape : basic shapes that you use to customize your applique\n#00ffbc  --Saved保存的图 : saved customized applique",
                "-5- change rotation and scale",
                " #fcfcfc hold MAG tool \n Press Q(toggle) \n 1-rotate \n 2-scaleSettings:X,Y,Z",
                "-6- change current color",
                " #fcfcfc hold MAG color reader \nleft click to scan and add color\n click the colors can change the color",
                "-7- Custom Applique System",
                "Red input can activate the #e0cbffCustom Applique System#fcfcfc \n SAVE can save current appliques as a customized applique \n You can put your appliques in any where \n because it'll recauculate the center position \n choose the last type of appliques to use your costumized applique \n 1-file name \n 2-existed files \n 3-Open selected file, new empty file, save current file"
            }
        },
        Mtools = {
            Chinese = {
                GunLc = "放置/删除贴花",
                GunRc = "删除模式",
                GunQ = "编辑旋转、大小、颜色",
                GunR = "设置贴花类型",
                GunDes = [[
    #fcfcfc
    MAG处理工具

    #00ffbc左键#fcfcfc放置贴花
    #00ffbc按住右键#fcfcfc时为删除模式
        此时再#00ffbc左键#fcfcfc可以删除贴花
    #00ffbcR#fcfcfc 切换贴花
    #00ffbcQ#fcfcfc 设置旋转、大小和颜色
                ]],
                PaintLc = "读取颜色/上色",
                PaintRc = "上色模式",
                PaintQ = "设置颜色",
                PaintDes = [[
    #fcfcfc
    MAG颜色工具

    #00ffbc左键#fcfcfc添加颜色
    #00ffbc按住右键#fcfcfc时为上色模式
    #00ffbcQ#fcfcfc 设置颜色
                ]],
                SelectorLc = "选择贴花",
                SelectorRc = "框取选择",
                SelectorQ = "取消选择",
                SelectorDes = [[
    #fcfcfc
    MAG选择工具

    #00ffbc左键#fcfcfc选择贴花
    #00ffbc右键#fcfcfc框取选择
    #00ffbcQ#fcfcfc 取消选择
                ]],
                EditorLc = "黏贴",
                EditorRc = "复制所选贴花",
                EditorQ = "编辑旋转、大小、颜色",
                EditorR = "镜像翻转复制的贴花",
                EditorDes = [[
    #fcfcfc
    MAG编辑工具

    #00ffbc左键#fcfcfc黏贴
    #00ffbc右键#fcfcfc复制所选贴花
    #00ffbcR#fcfcfc 镜像翻转复制的贴花
    #00ffbcQ#fcfcfc 编辑旋转、大小、颜色
                ]]
            },
            English = {
                GunLc = "place/erase applique",
                GunRc = "erase mode",
                GunQ = "edit rotation,scale,color",
                GunR = "set shape",
                GunDes = [[
    #fcfcfc
    MAG's operator tool!!

    #00ffbcleft click#fcfcfc to put on applique
    #00ffbcholding right click#fcfcfc is erase mode
        then #00ffbcleft click#fcfcfc to delete applique
    #00ffbcR#fcfcfc to switch applique
    #00ffbcQ#fcfcfc to set its rotation, scale and color
                ]],
                PaintLc = "scan/paint color",
                PaintRc = "paint mode",
                PaintQ = "set color",
                PaintDes = [[
    #fcfcfc
    MAG's paint tool!!

    #00ffbcleft click#fcfcfc to add color
    #00ffbcQ#fcfcfc to set its rotation, scale and color
                ]],
                SelectorLc = "select applique",
                SelectorRc = "select applique",
                SelectorQ = "cancel selection",
                SelectorDes = [[
    #fcfcfc
    MAG select tool

    #00ffbcleft click #fcfcfcselect applique
    #00ffbcright click #fcfcfcselect applique
    #00ffbcQ#fcfcfc #00ffbcQ#fcfcfc edit rotation,scale,color
                ]],
                EditorLc = "Paste",
                EditorRc = "Copy",
                EditorQ = "edit rotation,scale,color",
                EditorR = "mirror copied applique",
                EditorDes = [[
    #fcfcfc
    MAG editor

    #00ffbcLeft #fcfcfcto paste
    #00ffbcRight #fcfcfcto copy
    #00ffbcR#fcfcfc mirror copied applique
    #00ffbcQ#fcfcfc edit rotation,scale,color
                ]]
            }
        },
        MAC = {
            Chinese = {
                "同步数据到服务端中",
                "旋转 ",
                " 大小 ",
                "MACFileSystem",
                "文件不存在！",
                "文件导入成功！",
                "警告",
                "文件已存在，是否覆盖？",
                "文件保存成功！",
                "超出极限300，请另用另一个贴花装置",
                "最近的颜色",
                "该贴花保存于另一个模组中，无法覆盖",
                "重置",
                "镜像翻转",
                "发光",
                "法线锁定",
                "对齐精度",
                "点击颜色可读取\n点击Set可覆盖颜色",
                "Set"
            },
            English = {
                "sending data to server",
                "rotation ",
                " scaleXYZ ",
                "MAC file system",
                "File doesn't exist!",
                "File loaded successfully!",
                "WARNING",
                "File existed! Still save?",
                "File saved successfully!",
                "Over the limit of 300, please use another applique device",
                "recent colors",
                "File existed in another Mod that cant be saved",
                "Reset",
                "Mirror",
                "Glow",
                "normal lock",
                "align accuracy",
                "click to read color\nclick the Set button to set the color",
                "Set"
            }
        },
        CBK = {
            Chinese = {
                "用于房主备份贴花到蓝图中，下次更新后只需从蓝图取出就能恢复"
            },
            English = {
                "Appliques back up , reload your saved appliques when it is created from blueprint"
            }
        }
    }
end