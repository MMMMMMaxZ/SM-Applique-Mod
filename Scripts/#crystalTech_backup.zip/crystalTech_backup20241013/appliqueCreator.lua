-- MAXZ666 --
-- Max's applique creator
MAC = class(nil)
MAC.maxParentCount = 1
MAC.connectionInput = sm.interactable.connectionType.logic+sm.interactable.connectionType.power

MAC.colorNormal = sm.color.new(0x14514ff)
MAC.colorHighlight = sm.color.new(0x114514aa)

MAC.colorRed = "d02525ff"

syncTable = {}
syncPlayer = {}

--server
function MAC.server_onCreate(self)
    self.Server_effectTable = self.storage:load()
    if(self.Server_effectTable==nil)then
        self.Server_effectTable={}
    end
    self.Server_tableCnt = #self.Server_effectTable
    self.Server_lastInput = false

    self.runTime = 0
    self.lastPlayerList = sm.player.getAllPlayers()
    self.lastDeviceAmount = 0

    self.network:sendToClients("client_getSavedData",self.Server_effectTable)
end

function MAC.sv_syncData(self)
    local curRestTime -- = math.ceil(40*4*0.5^(#syncTable))
    if #syncTable~=0 then curRestTime = 10
    else curRestTime = 40*5 end
    self.runTime = (self.runTime + 1)%(curRestTime)
    if self.runTime ~= 0 then return end -- 每隔一段时间检查一次来优化
    local currentPlayerList = sm.player.getAllPlayers()
    -- > 除了同步问题
    if #syncTable~=0 and #syncTable == self.lastDeviceAmount then -- 没消去-->表首的装置不存在，需要清理
        syncPlayer[#syncPlayer]=nil
        syncTable[#syncTable]=nil
    end
    self.lastDeviceAmount = #syncTable
    if #syncTable == 0 or syncTable[#syncTable]~=self.shape.id then
        goto continue
    end
    if sm.exists(syncPlayer[#syncPlayer]) then
        self.network:sendToClient(syncPlayer[#syncPlayer],"client_getSavedData",self.Server_effectTable)
    end
    syncPlayer[#syncPlayer]=nil
    syncTable[#syncTable]=nil
    ::continue::
    if #currentPlayerList <= #self.lastPlayerList then
        self.lastPlayerList = currentPlayerList
        return
    end
    -- > 有玩家加入
    syncTable[#syncTable+1] = self.shape.id
    syncPlayer[#syncPlayer+1] = currentPlayerList[#currentPlayerList]
    self.lastPlayerList = currentPlayerList
end

function MAC.server_onFixedUpdate(self,dt)
    self.sv_input = self.interactable:getSingleParent()
    if self.sv_input ~= nil then
        self.sv_inputActive = self.sv_input:isActive()
    else
        self.sv_inputActive = false
    end
    if self.sv_inputActive then
        if tostring(self.sv_input.shape.color) == self.colorRed then
            self.interactable:setActive(false)
            if not self.Server_lastInput then
                local allPlayers = sm.player.getAllPlayers()
                local nPlayer = NearestPlayer(self.shape.worldPosition,allPlayers)
                self.network:sendToClient(nPlayer,"client_onFileOperate")
            end
        else
            self.interactable:setActive(true)
        end
    else 
        self.interactable:setActive(false)
    end
    self:sv_syncData()
    self.Server_lastInput = self.sv_inputActive
end

function MAC.server_saveData(self,data)
    self.Server_effectTable = {}
    local i=1
    for idx,data in pairs(data)do
        if not data.cleanFlag then
            self.Server_effectTable[i] = data
            i = i + 1
        end
    end
    self.storage:save(self.Server_effectTable)
    self.network:sendToClients("client_getSavedData",self.Server_effectTable)
end

function MAC.sv_onCreateBackUp(self)
    local allPlayers = sm.player.getAllPlayers()
    local hostChar = allPlayers[1]:getCharacter()
    local BKbody = sm.body.createBody(hostChar.worldPosition)
    BKbody:createPart(sm.uuid.new("51da94d6-a215-4f69-b569-c45bc1557d0f"),sm.vec3.new(0,0,0),sm.vec3.new(0,-1,0),sm.vec3.new(1,0,0))
end

function NearestPlayer(position , playerList)
	local distance  = nil
	local oupPlayer = nil
	for k,v in pairs(playerList)do
		local vD = sm.vec3.length2(position - v.character.worldPosition)
		if distance == nil or vD<distance then
			distance = vD
			oupPlayer = v
		end
	end
	return oupPlayer
end

--------------------------------------------client-----------------------------------------

function MAC.client_onCreate(self)
    if localPlayer == nil then
        dofile("$MOD_DATA/Scripts/crystalTech/_localPlayer.lua") -- 获取玩家操作
    end
    if CE == nil then
        dofile("$MOD_DATA/Scripts/crystalTech/_createEffects.lua") -- self:create_aplq()
        CE:init()
    end
    if MLines == nil then
        dofile("$MOD_DATA/Scripts/crystalTech/_MLines.lua") -- 适应多语言文本
        MLines:init()
    end
    if SS == nil then
        dofile("$MOD_DATA/Scripts/crystalTech/_selectSystem.lua") -- 用于编辑贴花（选择、对称）
        SS:init()
    end
    if TEST_POINT == nil then
        dofile("$MOD_DATA/Scripts/crystalTech/_testPoint.lua") -- 测试用的debug_draw
        TEST_POINT:init()
    end
    if MACP == nil then
        dofile("$MOD_DATA/Scripts/crystalTech/_MAC_Parameter.lua") -- 记录同一玩家的编辑参数
        MACP:init()
    end

    self.effectTableData = {}
    self.effectTable = {}
    self.tableCnt = 0

    self.localPlayer = sm.localPlayer.getPlayer()
    self.leftReady = true
    self.rightReady = true
    self.lastState = false -- false未启动，true启动

    self.currentEffect = sm.effect.createEffect("ShapeRenderable",self.interactable)
    self.currentEffect:setParameter("uuid",CE.effectUUIDList[1]["origin"])

    self.pointEffect = sm.effect.createEffect("point",self.interactable)

    self.selectedMAGData = {}
    self.selectedBox = sm.effect.createEffect("ShapeRenderable",self.interactable)
    self.selectedBox:setParameter("uuid",sm.uuid.new("5f41af56-df4c-4837-9b3c-10781335757f"))
    self.selectedBox:setParameter("color",sm.color.new("00fcfc"))
    self.selectedBoxText = sm.gui.createWorldIconGui(500,200,"$MOD_DATA/Gui/Layouts/HUD_WorldText.layout")
    self.eraseTag = false

    self.freeSelectBox = {
        st = nil,
        ed = nil,
        box = sm.effect.createEffect("ShapeRenderable",self.interactable),
        cP = nil,
        sP = nil
    }
    self.freeSelectBox.box:setParameter("uuid",sm.uuid.new("5f41af56-df4c-4837-9b3c-10781335757f"))
    self.freeSelectBox.box:setParameter("color",sm.color.new("00fcfc"))
end

function MAC.client_getSavedData(self,savedTable)
    self.effectTableData = savedTable
    self:translateData(self.effectTableData)
    self.tableCnt = #self.effectTableData + 1
    self.nearestEffectID = nil
    self.selectedMAGData = {}
end

function MAC.translateData(self,inputData)
    for k,v in pairs(self.effectTable)do
        v:destroy()
        self.effectTable[k]=nil
    end
    for idx,data in pairs(inputData)do
        if data.state == nil then data.state = "origin" end -- 旧版本没有贴花状态
        self.effectTable[idx] = sm.effect.createEffect("ShapeRenderable",self.interactable)
        self.effectTable[idx]:setParameter("uuid",CE.effectUUIDList[data.id][data.state])
        self.effectTable[idx]:setOffsetPosition(sm.vec3.new(data.offsetPosition.x,data.offsetPosition.y,data.offsetPosition.z))
        self.effectTable[idx]:setOffsetRotation(sm.quat.new(data.offsetRotation.x,data.offsetRotation.y,data.offsetRotation.z,data.offsetRotation.w))
        self.effectTable[idx]:setParameter("color",sm.color.new(data.color))
        self.effectTable[idx]:setScale(sm.vec3.new(data.scale.x,data.scale.y,data.scale.z)*0.255)
        self.effectTable[idx]:start()
    end
end

function MAC.changeCurrentEffect(self,changeColorFlag)
    self.currentEffect:destroy()
    self:findEfctPlyr()
    --MACP.currentScale.mirror = 1
    if CE.effectPlayer[MACP.currentEfctPlyr] ~= "Saved保存的图" then
        self.currentEffect = sm.effect.createEffect("ShapeRenderable",self.interactable)
        self.currentEffect:setScale(sm.vec3.new(MACP.scaleTable[MACP.currentScale.x]*MACP.currentScale.mirror,MACP.scaleTable[MACP.currentScale.y],MACP.scaleTable[MACP.currentScale.z])*0.255)
        self.currentEffect:setParameter("uuid",CE.effectUUIDList[MACP.currentEffectId][MACP.curAplqState])
    else
        self.currentEffect = sm.effect.createEffect("ShapeRenderable",self.interactable)
        self.currentEffect:setScale(sm.vec3.new(0.1,0.5,0.1)*0.255)
        self.currentEffect:setParameter("uuid",CE.effectUUIDList[1]["origin"])
        if MACP.selectedMAC == "Null" then
            self:cl_cleanCurrentMAC(true)
        else
            if MACP.selectedMACEfct == nil then
                local MacType = CE:MACexists(MACP.selectedMAC)
                if MacType == 0 then MacType = CurrentModType end -- 粘贴板 --> 本地
                MACP.selectedMACData = CE:fileOpen(MacType,MACP.selectedMAC)
                MACP.selectedMACEfct = {}
                for k,v in pairs(MACP.selectedMACData)do
                    if v.state == nil then v.state = "origin" end
                    MACP.selectedMACEfct[k] = sm.effect.createEffect("ShapeRenderable",self.interactable)
                    MACP.selectedMACEfct[k]:setParameter("uuid",CE.effectUUIDList[v.id][v.state])
                    --MACP.selectedMACEfct[k]:start()
                end
            elseif changeColorFlag then
                for k,v in pairs(MACP.selectedMACData)do
                    v.color = MACP.colorList[MACP.chosenColorType][MACP.chosenColorIdx]
                end
            end
        end
    end
    self.currentEffect:setOffsetPosition(self.shape.up*0.3)
    --self.currentEffect:start()
end

function MAC.findEfctPlyr(self)
    local oup
    for k,v in pairs(CE.efctPlyrCnt)do
        if MACP.currentEffectId >=v and MACP.currentEffectId <CE.efctPlyrCnt[k+1] then
            oup = k
        end
    end
    MACP.currentEfctPlyr = oup
    MACP.currentEfctPlus = MACP.currentEffectId - CE.efctPlyrCnt[MACP.currentEfctPlyr]
end

function MAC.client_onFixedUpdate(self,dt)
    if self.shape.body:isOnLift() then
        for idx,efct in pairs(self.effectTable)do
            if not efct:isPlaying() and not self.effectTableData[idx].cleanFlag then
                efct:start()
            end
        end
    end

    if self.interactable:isActive()then
        if self.lastState == false then --第一次启动获取最近玩家并绑定
            localPlayer:reset()
            self.lastState = true
            local allPlayers = sm.player.getAllPlayers()
            self.currentPlayer = NearestPlayer(self.shape.worldPosition,allPlayers)
            self.currentCharacter = self.currentPlayer.character
            
            if MACP.selectedMAC ~= "Null" and MACP.selectedMACData ~= nil then
                for k,v in pairs(MACP.selectedMACData)do
                    MACP.selectedMACEfct[k]:start()
                end
            end
            if self.localPlayer == self.currentPlayer then
                self.currentEffect:start()
                self:changeCurrentEffect(false)
            end
        end
        if self.localPlayer == self.currentPlayer then 
            --开始客户端的贴花编辑！
            local Left_condition = localPlayer.state.left   --self.currentCharacter:isAiming()
            local Right_condition = localPlayer.state.right  --self.currentCharacter:isCrouching()
            local R_condition = localPlayer.state.r
            local Q_condition = localPlayer.state.q
            local toolMode = localPlayer.tool

            local get,result = sm.localPlayer.getRaycast(10)
            if get then
                local offP,offR,hitNormal,fixRotation = self:cl_calculateRaycast(result)

                ----删除的箭头
                if (toolMode == "MAGgun" and Right_condition) or (toolMode == "MAGpainter" and Right_condition) or toolMode == "MAGselector" then
                    self:cl_generateSelectFlag(offP,fixRotation,hitNormal)
                else
                    self:cl_clearSelectFlag()
                end
                ----左键
                if not Left_condition then
                    if not self.leftReady then
                        -- 第一次松开
                    end
                    self.leftReady = true
                    --松开时
                    self:cl_setPreview(offP,offR,fixRotation,hitNormal)
                elseif self.leftReady then
                    self.leftReady = false
                    --第一次按下
                    if toolMode == "MAGgun" then
                        if not Right_condition then--put
                            self:cl_placeApplique(offP,offR,fixRotation,hitNormal)
                        else -- holding右键
                            if #self.effectTableData > 0 and self.nearestEffectID ~= nil then --erase
                                self:cl_eraseApplique(self.nearestEffectID)
                            end
                        end
                    elseif toolMode == "MAGeditor" then
                        if not Right_condition then--put
                            self:cl_placeApplique(offP,offR,fixRotation,hitNormal)
                        end
                    elseif toolMode == "MAGpainter" then
                        if not Right_condition then--put
                            self:cl_readColor(result)
                        else -- holding右键
                            if #self.effectTableData > 0 and self.nearestEffectID ~= nil then --paint
                                self:cl_paintApplique(self.nearestEffectID)
                            end
                        end
                        
                    elseif toolMode == "MAGselector" then
                        self:cl_addSelect(offP,0)
                    end
                else
                    --按下时
                end
                ----右键
                if not Right_condition then
                    if not self.rightReady then
                        -- 第一次松开
                        if toolMode == "MAGselector" then
                            self:cl_getFreeSelect()
                        end
                    end
                    --松开时
                    self.rightReady = true
                elseif self.rightReady then
                    self.rightReady = false
                    --第一次按下
                    if toolMode == "MAGeditor" then -- 复制所选贴花
                        self:cl_copySelected()
                    elseif toolMode == "MAGselector" then -- 自由框选
                        self:cl_setFreeSelectBoxStart(offP,fixRotation,hitNormal)
                    end
                else
                    --按下时
                    if toolMode == "MAGselector" then
                        self:cl_setFreeSelectBox(offP,fixRotation,hitNormal)
                    end
                end
            end
            --R
            if R_condition then
                if toolMode == "MAGgun" then -- 切换 特效种类
                    self:cl_createMAG_select_GUI()
                elseif toolMode == "MAGeditor" then
                    SS:setMirror(MACP.selectedMACEfct,MACP.selectedMACData,sm.vec3.new(0,0,0),sm.vec3.new(1,0,0))
                end
            end
            --Q
            if Q_condition then
                if toolMode == "MAGselector" then-- 清空选择
                    self:cl_clearSelect()
                elseif toolMode == "MAGpainter" then-- 颜色编辑
                    self:cl_createColorEditGui()
                else--设置 旋转和大小
                    self:cl_createMAG_rota_scale_color_GUI()
                end
            end
            --clear localPlayer state
            localPlayer:reset()
        end
    else
        if self.lastState == true then
            if self.localPlayer == self.currentPlayer then 
                TEST_POINT:clear()
                self.currentEffect:stop()
                self.selectedBox:stop()
                self.selectedBoxText:close()
                self:cl_cleanCurrentMAC(true)
                --send back data
                sm.gui.displayAlertText(MLines.lines["MAC"][MLines.currentLanguage][1],2)
                self.network:sendToServer("server_saveData",self.effectTableData)
            end
        end
        self.lastState = false
    end
end

function MAC.cl_setFreeSelectBoxStart(self,offP,fixRotation,hitNormal)
    local startPoint = offP + fixRotation*hitNormal*-0.03
    self.freeSelectBox.st = startPoint
    self.freeSelectBox.box:start()
end

function MAC.cl_setFreeSelectBox(self,offP,fixRotation,hitNormal)
    local endPoint = offP + fixRotation*hitNormal*0.03
    self.freeSelectBox.ed = endPoint
    local startPoint = self.freeSelectBox.st
    local tempET = {
        {
            offsetPosition = {x=startPoint.x,y=startPoint.y,z=startPoint.z}
        },
        {
            offsetPosition = {x=endPoint.x,y=endPoint.y,z=endPoint.z}
        }
    }
    local cP,sP = SS:getSelectedBox(tempET,true)
    self.freeSelectBox.cP = cP
    self.freeSelectBox.sP = sP
    self.freeSelectBox.box:setScale(sP)
    self.freeSelectBox.box:setOffsetPosition(cP)
end

function MAC.cl_getFreeSelect(self)
    local sT = SS:getFreeSelectApplique(self.freeSelectBox.cP,self.freeSelectBox.sP,self.effectTableData)
    for k,v in pairs(sT)do
        local curV = self.effectTableData[v]
        local VOffP = sm.vec3.new(curV.offsetPosition.x,curV.offsetPosition.y,curV.offsetPosition.z)
        self:cl_addSelect(VOffP,v)
    end
    self:cl_clearFreeSelect()
end

function MAC.cl_clearFreeSelect(self)
    if not self.freeSelectBox.box:isPlaying() then return end
    self.freeSelectBox.box:stop()
end

function MAC.cl_clearSelect(self)
    for k,v in pairs(self.selectedMAGData)do
        local PoffP = self.effectTableData[k].offsetPosition
        self.effectTable[k]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z))
    end
    self.selectedMAGData = {}
    self.selectedBox:stop()
    self.selectedBoxText:close()
end

function MAC.cl_addSelect(self,offP,vIdx)
    local nIdx,nDistance = vIdx,0
    if nIdx == 0 then nIdx,nDistance = self:cl_getNearestApplique(offP) end
    if(nDistance<=0.23)then
        if self.selectedMAGData[nIdx] then
            self.selectedMAGData[nIdx] = nil
        else
            self.selectedMAGData[nIdx] = true
        end
        local slData = {}
        for k,v in pairs(self.selectedMAGData)do
            slData[#slData+1] = self.effectTableData[k]
        end
        if #slData>0 then
            local centerP,scaleP = SS:getSelectedBox(slData,false)
            self.selectedBox:setScale(scaleP)
            self.selectedBox:setOffsetPosition(centerP)
            self.selectedBoxText:setText("Text"," "..tostring(#slData).." ")
            self.selectedBoxText:setWorldPosition(self.shape.worldPosition+self.shape.worldRotation*centerP)
            if #slData == 1 then
                self.selectedBox:start()
                self.selectedBoxText:open()
            end
        else
            if self.selectedBox:isPlaying() then
                self.selectedBox:stop()
                self.selectedBoxText:close()
            end
        end
        self:cl_clearSelectFlag()
    end
end

function MAC.cl_readColor(self,result)
    local hitShape = result:getShape()
    if hitShape ~= nil then
        local hitColor = hitShape.color
        local hitColorHexStr = hitColor:getHexStr()
        MACP.currentColor = hitColor
        hitColorHexStr = hitColorHexStr:sub(1,6)
        sm.gui.chatMessage("#"..hitColorHexStr.."-"..hitColorHexStr.."-")
        
        self:cl_painterColorRefresh(false,true)
    end
end

function MAC.cl_copySelected(self)
    local slData = {}
    for k,v in pairs(self.selectedMAGData)do
        slData[#slData+1] = self.effectTableData[k]
    end
    if #slData > 0 then
        self:cl_cleanCurrentMAC(true)
        MACP.currentEfctPlyr = #CE.efctPlyrCnt-1
        MACP.currentEfctPlus = 0
        MACP.currentEffectId = CE.efctPlyrCnt[#CE.efctPlyrCnt-1] + 0 -- 即贴花选择系统
        MACP.selectedMAC = "MaxCopy_079685746352413"
        local newList = CE:fileOpen(CurrentModType,"__List")
        self:cl_saveMAC(newList,slData,"MaxCopy_079685746352413")
        self:changeCurrentEffect(false)
    end
end

function MAC.cl_eraseApplique(self,nIdx) -- erase nearestEffectID
    if self.selectedMAGData[nIdx] then
        for k,v in pairs(self.selectedMAGData)do
            self.effectTableData[k].cleanFlag = true
            self.effectTable[k]:stop()
        end
        self.selectedMAGData = {}
        self.selectedBox:stop()
        self.selectedBoxText:close()
    else
        self.effectTableData[nIdx].cleanFlag = true
        self.effectTable[nIdx]:stop()
    end
end

function MAC.cl_paintApplique(self,nIdx) -- paint nearestEffectID
    local paintColorHexStr = MACP.currentColor:getHexStr()
    local paintColor = MACP.currentColor
    if self.selectedMAGData[nIdx] then
        for k,v in pairs(self.selectedMAGData)do
            self.effectTableData[k].color = paintColorHexStr
            self.effectTable[k]:setParameter("color",paintColor)
        end
    else
        self.effectTableData[nIdx].color = paintColorHexStr
        self.effectTable[nIdx]:setParameter("color",paintColor)
    end
end

function MAC.cl_placeApplique(self,offP,offR,fixRotation,hitNormal)
    if CE.effectPlayer[MACP.currentEfctPlyr] ~= "Saved保存的图" then
        if self:cl_checkOverSized(1) then -- not oversized
            local scaleV = sm.vec3.new(MACP.scaleTable[MACP.currentScale.x]*MACP.currentScale.mirror,MACP.scaleTable[MACP.currentScale.y],MACP.scaleTable[MACP.currentScale.z])
            self:cl_addEffect(MACP.currentEffectId,offP,offR,sm.color.new(MACP.colorList[MACP.chosenColorType][MACP.chosenColorIdx]),scaleV,false,MACP.curAplqState)
        end
    else
        if MACP.selectedMAC == "Null" then
           self:createMACselectGUI()
        else
            local loadedMAC = MACP.selectedMACData
            if loadedMAC ~= nil and self:cl_checkOverSized(#loadedMAC) then
                for k,v in pairs(loadedMAC)do
                    if v.state == nil then v.state = "origin" end
                    local scaleV = sm.vec3.new(MACP.scaleTable[MACP.currentScale.x],MACP.scaleTable[MACP.currentScale.y],MACP.scaleTable[MACP.currentScale.z])
                    local originVoffP = sm.vec3.new(v.offsetPosition.x,v.offsetPosition.y,v.offsetPosition.z)*scaleV
                    local originVoffR = sm.quat.new(v.offsetRotation.x,v.offsetRotation.y,v.offsetRotation.z,v.offsetRotation.w)
                    local originVscale = sm.vec3.new(v.scale.x,v.scale.y,v.scale.z)*scaleV
                    local fixedOffR = sm.quat.inverse(sm.quat.new(0,1,0,0))
                    local VoffP = offP+offR*fixedOffR*originVoffP+fixRotation*hitNormal*0.01
                    local VoffR = offR*fixedOffR*originVoffR

                    self:cl_addEffect(v.id,VoffP,VoffR,sm.color.new(v.color),originVscale,v.cleanFlag,v.state)
                end
            end
        end
    end
end

function MAC.cl_setPreview(self,offP,offR,fixRotation,hitNormal)
    self.currentEffect:setOffsetPosition(offP)
    self.currentEffect:setOffsetRotation(offR)
    self.currentEffect:setScale(sm.vec3.new(MACP.scaleTable[MACP.currentScale.x]*MACP.currentScale.mirror,MACP.scaleTable[MACP.currentScale.y],MACP.scaleTable[MACP.currentScale.z])*0.255)
    if CE.effectPlayer[MACP.currentEfctPlyr] ~= "Saved保存的图" then
        self.currentEffect:setParameter("color",sm.color.new(MACP.colorList[MACP.chosenColorType][MACP.chosenColorIdx]))
    elseif MACP.selectedMAC ~= "Null" and MACP.selectedMACData ~= nil then
        self.currentEffect:setScale(sm.vec3.new(0.1,0.5,0.1)*0.255)
        for k,v in pairs(MACP.selectedMACData)do
            local scaleV = sm.vec3.new(MACP.scaleTable[MACP.currentScale.x],MACP.scaleTable[MACP.currentScale.y],MACP.scaleTable[MACP.currentScale.z])
            local originVoffP = sm.vec3.new(v.offsetPosition.x,v.offsetPosition.y,v.offsetPosition.z)*scaleV
            local originVoffR = sm.quat.new(v.offsetRotation.x,v.offsetRotation.y,v.offsetRotation.z,v.offsetRotation.w)
            local originVscale = sm.vec3.new(v.scale.x,v.scale.y,v.scale.z)*scaleV
            local fixedOffR = sm.quat.inverse(sm.quat.new(0,1,0,0))
            local VoffP = offP+offR*fixedOffR*originVoffP+fixRotation*hitNormal*0.01
            local VoffR = offR*fixedOffR*originVoffR

            MACP.selectedMACEfct[k]:setParameter("color",sm.color.new(v.color))
            MACP.selectedMACEfct[k]:setScale(originVscale*0.255)
            MACP.selectedMACEfct[k]:setOffsetPosition(VoffP)
            MACP.selectedMACEfct[k]:setOffsetRotation(VoffR)
            MACP.selectedMACEfct[k]:start()
        end
    end
end

function MAC.cl_generateSelectFlag(self,offP,fixRotation,hitNormal) -- set nearestEffectID = nIdx
    local nIdx,nDistance = self:cl_getNearestApplique(offP)
    if(nDistance<=0.23)then
        self.eraseTag = true
        if self.nearestEffectID ~= nIdx and self.nearestEffectID ~= nil and self.effectTable[self.nearestEffectID]:isPlaying() then
            if self.selectedMAGData[self.nearestEffectID] then
                self.selectedBox:setParameter("color",sm.color.new("00fcfc"))
                for k,v in pairs(self.selectedMAGData)do
                    local PoffP = self.effectTableData[k].offsetPosition
                    self.effectTable[k]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z))
                end
            else
                local PoffP = self.effectTableData[self.nearestEffectID].offsetPosition
                self.effectTable[self.nearestEffectID]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z))
            end
        end
        self.nearestEffectID = nIdx
        local PoffP = self.effectTableData[nIdx].offsetPosition
        local PoffR = self.effectTableData[nIdx].offsetRotation
        self.pointEffect:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z))
        self.pointEffect:setOffsetRotation(sm.quat.new(PoffR.x,PoffR.y,PoffR.z,PoffR.w))
        if self.selectedMAGData[nIdx] then
            for k,v in pairs(self.selectedMAGData)do
                local PoffP = self.effectTableData[k].offsetPosition
                self.effectTable[k]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z)+fixRotation*hitNormal*0.05)
            end
            self.selectedBox:setParameter("color",sm.color.new("fc0000"))
        else
            self.effectTable[nIdx]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z)+fixRotation*hitNormal*0.05)
        end
        if not self.pointEffect:isPlaying() then self.pointEffect:start() end
        if self.currentEffect:isPlaying() then self.currentEffect:stop() end
    else
        if self.pointEffect:isPlaying() then self.pointEffect:stop() end
        if not self.currentEffect:isPlaying() then self.currentEffect:start() end
        if self.nearestEffectID ~= nil and self.effectTable[self.nearestEffectID]:isPlaying() then
            local PoffP = self.effectTableData[self.nearestEffectID].offsetPosition
            self.effectTable[self.nearestEffectID]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z))
            self.nearestEffectID = nil
        end
        if self.eraseTag then
            for k,v in pairs(self.selectedMAGData)do
                local PoffP = self.effectTableData[k].offsetPosition
                self.effectTable[k]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z))
            end
            self.selectedBox:setParameter("color",sm.color.new("00fcfc"))
            self.eraseTag = false
        end
        
    end
end

function MAC.cl_clearSelectFlag(self)
    if self.pointEffect:isPlaying() then self.pointEffect:stop() end
    if not self.currentEffect:isPlaying() then self.currentEffect:start() end
    if self.nearestEffectID ~= nil and self.effectTable[self.nearestEffectID]:isPlaying() then
        local PoffP = self.effectTableData[self.nearestEffectID].offsetPosition
        self.effectTable[self.nearestEffectID]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z))
        self.nearestEffectID = nil
    end
    if self.eraseTag then
        for k,v in pairs(self.selectedMAGData)do
            local PoffP = self.effectTableData[k].offsetPosition
            self.effectTable[k]:setOffsetPosition(sm.vec3.new(PoffP.x,PoffP.y,PoffP.z))
        end
        self.selectedBox:setParameter("color",sm.color.new("00fcfc"))
        self.eraseTag = false
    end
end

function MAC.cl_getNearestApplique(self,offP) -- return: nIdx,nDistance
    local nIdx,nDistance = 1,1000
    for idx,data in pairs(self.effectTableData)do
        if not data.cleanFlag then
            local ofp = offP - sm.vec3.new(data.offsetPosition.x,data.offsetPosition.y,data.offsetPosition.z)
            local ofpd = ofp:length()
            if ofpd <= nDistance then
                nDistance = ofpd
                nIdx = idx
            end
        end
    end
    return nIdx,nDistance
end

function MAC.cl_calculateRaycast(self,result)
    local hitLocation = result.pointWorld
    local hitNormal = result.normalWorld

    --法线修正：
    if MACP.fixNormalFlag then
        hitNormal = MACP.lastNormal
        TEST_POINT:show_test_point(1)
        TEST_POINT:set_test_point(1,hitLocation+hitNormal:normalize()*0.06)
    else
        MACP.lastNormal = hitNormal
        TEST_POINT:stop_test_point(1)
    end

    local nhitN = hitNormal:normalize()
    local nAt = self.shape.at:normalize()
    local cosK = sm.vec3.dot(nAt,nhitN)
    local KStandard = -1 -- represent the front side
    local errorRange = 0.01
    if cosK-KStandard <= errorRange then
        hitNormal = self.shape.at*-1
    end

    local fixRotation = sm.quat.inverse(self.shape.worldRotation)
    local offR = sm.vec3.getRotation(fixRotation*self.shape.at,fixRotation*hitNormal)
    local offP = fixRotation*(hitLocation-self.shape.worldPosition)

    --offP对齐修正
    if MACP.curAlign > 1 then
        local offFixV = sm.vec3.new(1,1,1)*(0.25/4/MACP.alignTable[MACP.curAlign])
        offP = offP + offFixV
        offP = offP*10*MACP.alignTable[MACP.curAlign]
        offP = sm.vec3.new(math.floor(offP.x),math.floor(offP.y),math.floor(offP.z))/MACP.alignTable[MACP.curAlign]/10 + hitNormal*0.25/MACP.alignTable[MACP.curAlign]
    end

    local efctUp = sm.quat.getUp(offR)
    local efctAt = sm.quat.getAt(offR)
    local efctRotaAt = efctAt:rotate(MACP.rotaTable[MACP.currentRotation]/180*3.14,efctUp)
    local efctRota = sm.vec3.getRotation(efctAt,efctRotaAt)
    offR = efctRota*offR
    return offP,offR,hitNormal,fixRotation
end

function MAC.cl_cleanCurrentMAC(self,resetMACflag)
    if MACP.selectedMACEfct~=nil then
        for k,v in pairs(MACP.selectedMACEfct)do
            v:destroy()
        end
        MACP.selectedMACEfct = nil
    end
    if resetMACflag then
        MACP.selectedMAC = "Null"
    end
    MACP.selectedMACData = nil
end

function MAC.cl_checkOverSized(self,addT)
    local limit = 270
    if #self.effectTableData + addT > limit then
        sm.gui.displayAlertText(MLines.lines["MAC"][MLines.currentLanguage][10])
        return false
    else
        return true
    end
end

function MAC.cl_addEffect(self,id,offP,offR,color,scale,cleanFlag,state)
    self.effectTable[self.tableCnt]=sm.effect.createEffect("ShapeRenderable",self.interactable)
    self.effectTable[self.tableCnt]:setParameter("uuid",CE.effectUUIDList[id][state])
    self.effectTable[self.tableCnt]:setParameter("color",color)
    self.effectTable[self.tableCnt]:setScale(scale*0.255)
    self.effectTable[self.tableCnt]:setOffsetPosition(offP)
    self.effectTable[self.tableCnt]:setOffsetRotation(offR)
    self.effectTable[self.tableCnt]:start()
    self.effectTableData[self.tableCnt]={
        id = id ,
        state = state ,
        offsetPosition = {x=offP.x,y=offP.y,z=offP.z},
        offsetRotation = {x=offR.x,y=offR.y,z=offR.z,w=offR.w},
        color = color:getHexStr(),
        scale = {x=scale.x,y=scale.y,z=scale.z},
        cleanFlag = cleanFlag
    }
    self.tableCnt = self.tableCnt + 1

end

function MAC.cl_createMAG_select_GUI(self)
    self:cl_cleanCurrentMAC(true)
    self:findEfctPlyr()
    self.gui = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/MAG_int_V4.layout")
    self.gui:setText("Name", " MAG ")
    self:cl_appliqueChangedGuiRefresh()
    self.gui:createHorizontalSlider("slider1",#CE.effectPlayer-1,MACP.currentEfctPlyr-1,"client_onSliderChangePlayer",true)
    --self.gui:createHorizontalSlider("slider2",20,MACP.currentEfctPlus,"client_onSliderChangeApplique",true)
    self.gui:setImage("Tutorial","$MOD_DATA/Gui/Layouts/black.png")

    for i=1,30 do
        self.gui:setButtonCallback( "apqButton" .. tostring(i), "cl_chooseApplique" ) 
    end

    self:cl_itemListRefresh()
    self:cl_appliqueChangedGuiRefresh()

    self.gui:setOnCloseCallback("client_onClose")
    self.gui:open()
end

function MAC.cl_createMAG_rota_scale_color_GUI(self)
    self.gui = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/MAG_rota_scale_color_V3.layout")
    self.gui:setText("Name", "Rotation Scale Color")
    self.gui:setText("SubTitle", MLines.lines["MAC"][MLines.currentLanguage][2]..MACP.rotaTable[MACP.currentRotation]..MLines.lines["MAC"][MLines.currentLanguage][3]..MACP.scaleTable[MACP.currentScale.x]..","..MACP.scaleTable[MACP.currentScale.y]..","..MACP.scaleTable[MACP.currentScale.z])
    self.gui:setText("colorText",MLines.lines["MAC"][MLines.currentLanguage][11])
    self.gui:setImage("Tutorial","$MOD_DATA/Gui/Layouts/black.png")

    for k,name in pairs({"HorizonImg","VerticalImg","LayerImg","RotationImg"})do
        self.gui:setImage(name,"$MOD_DATA/Gui/Layouts/MAG/"..name..".png")
    end
    self.gui:createHorizontalSlider("slider1",#MACP.rotaTable,MACP.currentRotation,"client_onSliderChangeOffRota",false)
    self.gui:createHorizontalSlider("slider2",#MACP.scaleTable,MACP.currentScale.x-1,"client_onSliderChangeScaleX",false)
    self.gui:createVerticalSlider("slider3",#MACP.scaleTable,MACP.currentScale.y-1,"client_onSliderChangeScaleY")
    self.gui:createVerticalSlider("slider4",#MACP.scaleTable,MACP.currentScale.z-1,"client_onSliderChangeScaleZ")

    self.gui:setText("xText",tostring(MACP.scaleTable[MACP.currentScale.x]))
    self.gui:setText("yText",tostring(MACP.scaleTable[MACP.currentScale.y]))
    self.gui:setText("zText",tostring(MACP.scaleTable[MACP.currentScale.z]))
    self.gui:setText("rText",tostring(MACP.rotaTable[MACP.currentRotation]))

    self.gui:createHorizontalSlider("alignSlider",#MACP.alignTable,MACP.curAlign-1,"client_onSliderChangeAlign",false)
    self.gui:setText("AlignText",MLines.lines["MAC"][MLines.currentLanguage][17])
    
    for k=1, 10 do
        self.gui:setColor("emptyColorA" .. tostring(k),sm.color.new(MACP.colorList[MACP.chosenColorType][k]))
        self.gui:setButtonCallback( "colorB" .. tostring(k), "cl_chooseColor" ) 
    end
    
    self.gui:createVerticalSlider("ColorTypeSlider",#MACP.colorList,#MACP.colorList-MACP.chosenColorType,"client_onSliderChangeColorType")

    self.gui:setButtonCallback("ResetButton","cl_onResetQstate")
    self.gui:setText("ResetButton",MLines.lines["MAC"][MLines.currentLanguage][13])
    self.gui:setButtonCallback("MirrorButton","cl_onMirrorQstate")
    self.gui:setText("MirrorButton",MLines.lines["MAC"][MLines.currentLanguage][14])
    self.gui:setButtonCallback("GlowButton","cl_onGlowQstate")
    self.gui:setText("GlowButton",MLines.lines["MAC"][MLines.currentLanguage][15])

    self.gui:setButtonCallback("fixNormal","cl_onFixNormalQstate")
    self.gui:setText("fixNormalText",MLines.lines["MAC"][MLines.currentLanguage][16])
    self.gui:setImage("fixNormalImage","$MOD_DATA/Gui/Layouts/MAG/FixNormalImg.png")

    self.gui:setOnCloseCallback("client_onClose")
    self.gui:open()
end

function MAC.cl_createColorEditGui(self)
    self.gui = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/MAG_color_edit.layout")
    self.gui:setText("Name", "Edit Color")
    self.gui:setText("colorText",MLines.lines["MAC"][MLines.currentLanguage][18])
    
    for k=1, 10 do
        self.gui:setColor("emptyColorA" .. tostring(k),sm.color.new(MACP.colorList[MACP.chosenColorType][k]))
        self.gui:setButtonCallback( "colorB" .. tostring(k), "cl_readGUIColor" ) 
    end
    for k=1, 10 do
        self.gui:setText("readColorB" .. tostring(k),MLines.lines["MAC"][MLines.currentLanguage][19])
        self.gui:setButtonCallback( "readColorB" .. tostring(k), "cl_setGUIColor" ) 
    end
    
    self.gui:createVerticalSlider("ColorTypeSlider",#MACP.colorList,#MACP.colorList-MACP.chosenColorType,"client_onSliderChangeColorType")

    local curHexStr = MACP.currentColor:getHexStr():sub(1,6)
    self.gui:setText("editHexStr","##"..curHexStr:upper())
    self.gui:setColor("emptyEditA",MACP.currentColor)
    self.gui:createHorizontalSlider("Rslider",256,MACP.currentColor.r*255,"client_onSliderChangeColorR",false)
    self.gui:createHorizontalSlider("Gslider",256,MACP.currentColor.g*255,"client_onSliderChangeColorG",false)
    self.gui:createHorizontalSlider("Bslider",256,MACP.currentColor.b*255,"client_onSliderChangeColorB",false)

    self.gui:setOnCloseCallback("client_onClose")
    self.gui:open()
end

function MAC.client_onFileOperate(self)
    if self.gui ~= nil then return end
    MACP.MACfiles = CE:getMACfiles()
    self.tempMACname = 1
    self.gui = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/MAC_int.layout" , false)
    --self.gui:setText("Name", MLines.lines["MAC"][MLines.currentLanguage][4])
    self.gui:setTextChangedCallback("AppliqueName","cl_onChangeApqName")
    self.gui:setTextAcceptedCallback("AppliqueName","cl_onChangeDoneApqName")
    if MACP.fileName == "Name" then MACP.fileName = MACP.MACfiles[1] end
    self.gui:setText("AppliqueName",MACP.fileName)
    self.gui:createDropDown("AppliqueList","cl_onDropDownInteract",MACP.MACfiles)
    self.gui:setSelectedDropDownItem("AppliqueList", MACP.MACfiles[1])
    self.gui:setButtonCallback("NewButton","cl_onNewMAC")
    self.gui:setButtonCallback("OpenButton","cl_onOpenMAC")
    self.gui:setButtonCallback("SaveButton","cl_onSaveMAC")
    self.gui:setOnCloseCallback("client_onClose")
    self.gui:open()
end

function MAC.createMACselectGUI(self)
    if self.gui ~= nil then return end
    MACP.MACfiles = CE:getMACfiles()
    self.tempMACname = 1
    self.gui = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/MAC_fileOpen.layout" , false)
    --self.gui:setText("Name", MLines.lines["MAC"][MLines.currentLanguage][4])
    self.gui:createDropDown("AppliqueList","cl_onDropDownSelect",MACP.MACfiles)
    self.gui:setSelectedDropDownItem("AppliqueList", MACP.MACfiles[1])
    self.gui:setButtonCallback("OpenButton","cl_onOpenSelectedMAC")
    self.gui:setOnCloseCallback("client_onClose")
    self.gui:open()
end

function MAC.cl_painterColorRefresh(self,guiChange,specialSet)
    if specialSet then
        MACP.chosenColorType = 5
        MACP.chosenColorIdx = 11
        MACP.colorList[5][11] = MACP.currentColor:getHexStr()
    end
    self:changeCurrentEffect(true)
    if guiChange then
        local curHexStr = MACP.currentColor:getHexStr():sub(1,6)
        self.gui:setText("editHexStr","##"..curHexStr:upper())
        self.gui:setColor("emptyEditA",MACP.currentColor)
        for k=1, 10 do
            self.gui:setColor("emptyColorA" .. tostring(k),sm.color.new(MACP.colorList[MACP.chosenColorType][k]))
            self.gui:setButtonCallback( "colorB" .. tostring(k), "cl_readGUIColor" ) 
        end
        self.gui:setSliderPosition("ColorTypeSlider",5-MACP.chosenColorType)
    end
end

function MAC.cl_setGUIColor(self,button)
    local buttonId = tonumber(button:match("(%d+)"))
    if type(buttonId) == "nil" or MACP.chosenColorType<=4 then return end
    self.gui:setColor("emptyColorA" .. tostring(buttonId),MACP.currentColor)
    MACP.colorList[MACP.chosenColorType][buttonId] = MACP.currentColor:getHexStr()
end

function MAC.cl_readGUIColor(self,button)
    local buttonId = tonumber(button:match("(%d+)"))
    MACP.chosenColorIdx = buttonId
    if type(buttonId) == "nil" then return end
    MACP.currentColor = sm.color.new(MACP.colorList[MACP.chosenColorType][buttonId])
    self:cl_painterColorRefresh(true,false)
    self.gui:setSliderPosition("Rslider",MACP.currentColor.r*255)
    self.gui:setSliderPosition("Gslider",MACP.currentColor.g*255)
    self.gui:setSliderPosition("Bslider",MACP.currentColor.b*255)
end

function MAC.client_onSliderChangeColorR(self,sliderPos)
    MACP.currentColor.r=(sliderPos/255)
    self:cl_painterColorRefresh(true,true)
end

function MAC.client_onSliderChangeColorG(self,sliderPos)
    MACP.currentColor.g=(sliderPos/255)
    self:cl_painterColorRefresh(true,true)
end

function MAC.client_onSliderChangeColorB(self,sliderPos)
    MACP.currentColor.b=(sliderPos/255)
    self:cl_painterColorRefresh(true,true)
end

function MAC.cl_chooseColor(self,button)
    local buttonId = tonumber(button:match("(%d+)"))
    MACP.chosenColorIdx = buttonId
    self:changeCurrentEffect(true)
end

function MAC.cl_onDropDownSelect(self,DDname)
    MACP.selectedMAC = DDname
end

function MAC.cl_onOpenSelectedMAC(self)
    self.gui:close()
end

function MAC.cl_onChangeApqName(self,editBoxName,MACname)
    MACP.fileName = MACname
end

function MAC.cl_onChangeDoneApqName(self,editBoxName,MACname)
    MACP.fileName = MACname
end

function MAC.cl_onDropDownInteract(self,DDname)
    MACP.fileName = DDname
    self.gui:setText("AppliqueName",MACP.fileName)
end

function MAC.cl_onNewMAC(self,button)
    self.network:sendToServer("server_saveData",{})
    self.effectTableData={}
end

function MAC.cl_onOpenMAC(self,button)
    local MacType = CE:MACexists(MACP.fileName)
    local MacExist = false
    if MacType == 0 then MacExist,MacType = CE:fileExists(0,MACP.fileName) end
    if MacType == 0 then
        sm.gui.chatMessage(MLines.lines["MAC"][MLines.currentLanguage][5])
        self.effectTableData = {}
    else
        self.effectTableData = CE:fileOpen(MacType,MACP.fileName)
        sm.gui.chatMessage(MLines.lines["MAC"][MLines.currentLanguage][6])
    end
    self.network:sendToServer("server_saveData",self.effectTableData)
end

function MAC.cl_onSaveMAC(self,button)
    local existType = CE:MACexists(MACP.fileName)
    --create New added List
    local newList = CE:fileOpen(CurrentModType,"__List")
    if existType == 0 then
        --MACP.MACfiles[#MACP.MACfiles+1] = MACP.fileName
        newList[#newList+1] = MACP.fileName
        self:cl_saveMAC(newList,self.effectTableData,MACP.fileName)
    elseif existType == CurrentModType then -- 本地重名
        self.gui:close()
        self.warningGUI = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/warning.layout",true)
        self.warningGUI:setText("Name", MLines.lines["MAC"][MLines.currentLanguage][7])
        self.warningGUI:setText("SubTitle", MLines.lines["MAC"][MLines.currentLanguage][8])
        self.warningGUI:setButtonCallback("No","cl_wnNo")
        self.warningGUI:setButtonCallback("Yes","cl_wnYes")
        self.warningGUI:open()
    else -- 异地重名
        self.gui:close()
        self.warningGUI = sm.gui.createGuiFromLayout("$MOD_DATA/Gui/Layouts/warning.layout",true)
        self.warningGUI:setText("Name", MLines.lines["MAC"][MLines.currentLanguage][7])
        self.warningGUI:setText("SubTitle", MLines.lines["MAC"][MLines.currentLanguage][12])
        self.warningGUI:setButtonCallback("No","cl_wnNo")
        self.warningGUI:setButtonCallback("Yes","cl_wnNo")
        self.warningGUI:open()
    end
end

function MAC.cl_saveMAC(self,newList,efctTableData,fileName)
    local centerPosition = sm.vec3.new(0,0,0)
    local fullDeltaPlus = 0
    local FDPstandard = 0.95
    local fixRotation = sm.quat.inverse(self.shape.worldRotation)
    local targetAt = fixRotation*self.shape.at
    local averUp = sm.vec3.new(0,0,0)
    local adjustFlag = false
    local adjustRota
    if #efctTableData ~= 0 then
        for k,v in pairs(efctTableData)do
            centerPosition = centerPosition + sm.vec3.new(v.offsetPosition.x,v.offsetPosition.y,v.offsetPosition.z)
            local offsetRotation = sm.quat.new(v.offsetRotation.x,v.offsetRotation.y,v.offsetRotation.z,v.offsetRotation.w)
            local offRUp = sm.quat.getUp(offsetRotation)
            averUp = averUp + offRUp
        end
        averUp = averUp:normalize()
        for k,v in pairs(efctTableData)do
            local offsetRotation = sm.quat.new(v.offsetRotation.x,v.offsetRotation.y,v.offsetRotation.z,v.offsetRotation.w)
            local offRUp = sm.quat.getUp(offsetRotation)
            local cosK = sm.vec3.dot(averUp,offRUp)
            fullDeltaPlus = fullDeltaPlus + (cosK+1)/2
        end
        fullDeltaPlus = fullDeltaPlus/#efctTableData
        adjustFlag = fullDeltaPlus >= FDPstandard -- 太大偏差说明故意偏的
        if adjustFlag then
            adjustRota = sm.vec3.getRotation(averUp,targetAt)
        end
        centerPosition = centerPosition/#efctTableData
        for k,v in pairs(efctTableData)do
            local VnewOffPosition = sm.vec3.new(v.offsetPosition.x,v.offsetPosition.y,v.offsetPosition.z)-centerPosition
            if adjustFlag then
                VnewOffPosition = adjustRota*VnewOffPosition
                local VnOffR = adjustRota*sm.quat.new(v.offsetRotation.x,v.offsetRotation.y,v.offsetRotation.z,v.offsetRotation.w)
                v.offsetRotation = {x=VnOffR.x,y=VnOffR.y,z=VnOffR.z,w=VnOffR.w}
            end
            v.offsetPosition = {x=VnewOffPosition.x,y=VnewOffPosition.y,z=VnewOffPosition.z}
        end
        sm.json.save(newList,"$CONTENT_"..FileMODuuid.."/Appliques/__List.json")
        sm.json.save(efctTableData,"$CONTENT_"..FileMODuuid.."/Appliques/"..fileName..".json")
        sm.gui.chatMessage(MLines.lines["MAC"][MLines.currentLanguage][9])
        if sm.isHost and fileName ~= "MaxCopy_079685746352413" then
            self.network:sendToServer("sv_onCreateBackUp")
        end
        --reverse operation
        if adjustFlag then adjustRota = sm.quat.inverse(adjustRota) end
        for k,v in pairs(efctTableData)do
            local VnewOffPosition = sm.vec3.new(v.offsetPosition.x,v.offsetPosition.y,v.offsetPosition.z)
            if adjustFlag then
                VnewOffPosition = adjustRota*VnewOffPosition
                local VnOffR = adjustRota*sm.quat.new(v.offsetRotation.x,v.offsetRotation.y,v.offsetRotation.z,v.offsetRotation.w)
                v.offsetRotation = {x=VnOffR.x,y=VnOffR.y,z=VnOffR.z,w=VnOffR.w}
            end
            VnewOffPosition = VnewOffPosition + centerPosition
            v.offsetPosition = {x=VnewOffPosition.x,y=VnewOffPosition.y,z=VnewOffPosition.z}
        end
    end
end

function MAC.cl_wnNo(self)
    self.warningGUI:close()
    self:client_onFileOperate()
end

function MAC.cl_wnYes(self) -- 本地重名
    local newList = CE:fileOpen(CurrentModType,"__List")
    self:cl_saveMAC(newList,self.effectTableData,MACP.fileName)
    self.warningGUI:close()
end

function MAC.client_onSliderChangePlayer(self, sliderPos)
    MACP.currentEfctPlyr = sliderPos+1
    MACP.currentEfctPlus = 0
    MACP.currentEffectId = CE.efctPlyrCnt[MACP.currentEfctPlyr]+MACP.currentEfctPlus

    MACP.curAplqState = "origin"

    self:cl_itemListRefresh()
    self:cl_appliqueChangedGuiRefresh()
    self:changeCurrentEffect(false)
end
--[[
function MAC.client_onSliderChangeApplique(self, sliderPos)
    if sliderPos >= CE.efctPlyrCnt[MACP.currentEfctPlyr+1]-CE.efctPlyrCnt[MACP.currentEfctPlyr]  then
        MACP.currentEfctPlus = CE.efctPlyrCnt[MACP.currentEfctPlyr+1]-CE.efctPlyrCnt[MACP.currentEfctPlyr] - 1
    else
        MACP.currentEfctPlus = sliderPos
    end
    
    MACP.currentEffectId = CE.efctPlyrCnt[MACP.currentEfctPlyr]+MACP.currentEfctPlus
    self:cl_appliqueChangedGuiRefresh()
    self:changeCurrentEffect(false)
end
]]
function MAC.cl_itemListRefresh(self)
    if self.gui == nil then return end
    if CE.effectPlayer[MACP.currentEfctPlyr] ~= "Saved保存的图" then
        for id = CE.efctPlyrCnt[MACP.currentEfctPlyr] , CE.efctPlyrCnt[MACP.currentEfctPlyr+1]-1 do
            self.gui:setIconImage("item"..tostring(id-CE.efctPlyrCnt[MACP.currentEfctPlyr]+1),CE.effectUUIDList[id]["origin"])
        end
        for id = CE.efctPlyrCnt[MACP.currentEfctPlyr+1] - CE.efctPlyrCnt[MACP.currentEfctPlyr] + 1 , 30 do
            self.gui:setIconImage("item"..tostring(id),sm.uuid.getNil())
        end
    else
        for id = 1 , 30 do
            self.gui:setIconImage("item"..tostring(id),sm.uuid.getNil())
        end
    end
end

function MAC.cl_chooseApplique(self,button)
    if self.gui == nil then return end
    if CE.effectPlayer[MACP.currentEfctPlyr] == "Saved保存的图" then return end
    local buttonId = tonumber(button:match("(%d+)"))
    if buttonId >= CE.efctPlyrCnt[MACP.currentEfctPlyr+1]-CE.efctPlyrCnt[MACP.currentEfctPlyr] + 1 then return end
    MACP.currentEfctPlus = buttonId-1
    MACP.currentEffectId = CE.efctPlyrCnt[MACP.currentEfctPlyr]+MACP.currentEfctPlus
    self:cl_appliqueChangedGuiRefresh()
    self:changeCurrentEffect(false)
end

function MAC.cl_appliqueChangedGuiRefresh(self)
    if self.gui == nil then return end
    if CE.effectPlayer[MACP.currentEfctPlyr] ~= "Saved保存的图" then 
        self.gui:setIconImage("itemPreview",CE.effectUUIDList[MACP.currentEffectId]["origin"]) 
    else
        self.gui:setIconImage("itemPreview",self.shape.uuid) 
    end
    self.gui:setText("SubTitle", CE.effectPlayer[MACP.currentEfctPlyr].." : "..CE.effectList[MACP.currentEffectId])
end

function MAC.client_onSliderChangeOffRota(self, sliderPos)
    MACP.currentRotation = sliderPos
    self.gui:setText("SubTitle", MLines.lines["MAC"][MLines.currentLanguage][2]..MACP.rotaTable[MACP.currentRotation]..MLines.lines["MAC"][MLines.currentLanguage][3]..MACP.scaleTable[MACP.currentScale.x]..","..MACP.scaleTable[MACP.currentScale.y]..","..MACP.scaleTable[MACP.currentScale.z])
    self.gui:setText("rText",tostring(MACP.rotaTable[MACP.currentRotation]))
    self:changeCurrentEffect(false)
end

function MAC.client_onSliderChangeScaleX(self, sliderPos)
    MACP.currentScale.x = sliderPos+1
    self.gui:setText("SubTitle", MLines.lines["MAC"][MLines.currentLanguage][2]..MACP.rotaTable[MACP.currentRotation]..MLines.lines["MAC"][MLines.currentLanguage][3]..MACP.scaleTable[MACP.currentScale.x]..","..MACP.scaleTable[MACP.currentScale.y]..","..MACP.scaleTable[MACP.currentScale.z])
    self.gui:setText("xText",tostring(MACP.scaleTable[MACP.currentScale.x]))
    self:changeCurrentEffect(false)
end

function MAC.client_onSliderChangeScaleY(self, sliderPos)
    MACP.currentScale.y = sliderPos+1
    self.gui:setText("SubTitle", MLines.lines["MAC"][MLines.currentLanguage][2]..MACP.rotaTable[MACP.currentRotation]..MLines.lines["MAC"][MLines.currentLanguage][3]..MACP.scaleTable[MACP.currentScale.x]..","..MACP.scaleTable[MACP.currentScale.y]..","..MACP.scaleTable[MACP.currentScale.z])
    self.gui:setText("yText",tostring(MACP.scaleTable[MACP.currentScale.y]))
    self:changeCurrentEffect(false)
end

function MAC.client_onSliderChangeScaleZ(self, sliderPos)
    MACP.currentScale.z = sliderPos+1
    self.gui:setText("SubTitle", MLines.lines["MAC"][MLines.currentLanguage][2]..MACP.rotaTable[MACP.currentRotation]..MLines.lines["MAC"][MLines.currentLanguage][3]..MACP.scaleTable[MACP.currentScale.x]..","..MACP.scaleTable[MACP.currentScale.y]..","..MACP.scaleTable[MACP.currentScale.z])
    self.gui:setText("zText",tostring(MACP.scaleTable[MACP.currentScale.z]))
    self:changeCurrentEffect(false)
end

function MAC.client_onSliderChangeAlign(self, sliderPos)
    MACP.curAlign = sliderPos + 1
end

function MAC.client_onSliderChangeColorType(self,sliderPos)
    MACP.chosenColorType = #MACP.colorList-sliderPos
    if MACP.chosenColorIdx > 10 then
        MACP.chosenColorIdx = 1
    end
    for k=1, 10 do
        self.gui:setColor("emptyColorA" .. tostring(k),sm.color.new(MACP.colorList[MACP.chosenColorType][k]))
    end
end

function MAC.cl_onResetQstate(self,button)
    MACP.currentScale.x = 10
    MACP.currentScale.y = 10
    MACP.currentScale.z = 10
    MACP.curAlign = 1
    MACP.currentScale.mirror = 1
    MACP.curAplqState = "origin"
    MACP.fixNormalFlag = false
    MACP.currentRotation = 36
    self.gui:setSliderPosition("slider1",36)
    self.gui:setSliderPosition("slider2",9)
    self.gui:setSliderPosition("slider3",9)
    self.gui:setSliderPosition("slider4",9)
    self.gui:setSliderPosition("alignSlider",0)
    self.gui:setText("SubTitle", MLines.lines["MAC"][MLines.currentLanguage][2]..MACP.rotaTable[MACP.currentRotation]..MLines.lines["MAC"][MLines.currentLanguage][3]..MACP.scaleTable[MACP.currentScale.x]..","..MACP.scaleTable[MACP.currentScale.y]..","..MACP.scaleTable[MACP.currentScale.z])
    self.gui:setText("xText",tostring(MACP.scaleTable[MACP.currentScale.x]))
    self.gui:setText("yText",tostring(MACP.scaleTable[MACP.currentScale.y]))
    self.gui:setText("zText",tostring(MACP.scaleTable[MACP.currentScale.z]))
    self.gui:setText("rText",tostring(MACP.rotaTable[MACP.currentRotation]))
    if CE.effectPlayer[MACP.currentEfctPlyr] == "Saved保存的图" and MACP.selectedMACData~=nil then
        self:cl_cleanCurrentMAC(false)
        local MacType = CE:MACexists(MACP.selectedMAC)
        if MacType == 0 then MacType = CurrentModType end -- 粘贴板 --> 本地
        MACP.selectedMACData = CE:fileOpen(MacType,MACP.selectedMAC)
        MACP.selectedMACEfct = {}
        for k,v in pairs(MACP.selectedMACData)do
            if v.state == nil then v.state = "origin" end
            MACP.selectedMACEfct[k] = sm.effect.createEffect("ShapeRenderable",self.interactable)
            MACP.selectedMACEfct[k]:setParameter("uuid",CE.effectUUIDList[v.id][v.state])
            --MACP.selectedMACEfct[k]:start()
        end
    end
    self:changeCurrentEffect(false)
end

function MAC.cl_onMirrorQstate(self,button)
    MACP.currentScale.mirror = -1*MACP.currentScale.mirror
    SS:setMirror(MACP.selectedMACEfct,MACP.selectedMACData,sm.vec3.new(0,0,0),sm.vec3.new(1,0,0))
end

function MAC.cl_onGlowQstate(self,button)
    MACP.curAplqState = MACP.curAplqStateTable[MACP.curAplqState]
    if CE.effectPlayer[MACP.currentEfctPlyr] == "Saved保存的图" or CE.effectUUIDList[MACP.currentEffectId][MACP.curAplqState] == 0 then
        MACP.curAplqState = "origin"
    end
    self:changeCurrentEffect(false)
end

function MAC.cl_onFixNormalQstate(self,button)
    MACP.fixNormalFlag = not MACP.fixNormalFlag
end

function MAC.client_onClose(self)
    if self.gui then
        self.gui:close()
        self.gui:destroy()
        self.gui = nil
    end
    self:changeCurrentEffect(false)
end