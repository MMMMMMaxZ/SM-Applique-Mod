-- MAXZ666 --
-- Max's applique creator tutorial!
MACT = class(nil)

function MACT.client_onCreate(self)
    if MTt == nil then
        dofile("$MOD_DATA/Scripts/crystalTech/_MAGtutorial.lua")
        MTt:init()
    end
end

function MACT.client_onInteract(self,character,state)
	if state then
        local maxPage = #MTt.book.titles
		self.gui = sm.gui.createGuiFromLayout('$MOD_DATA/Gui/Layouts/MAGtutorial.layout')
        self.gui:createDropDown("List","cl_onDropDownInteract",MTt.book.titles)
        self.gui:setButtonCallback("UpButton","cl_onUpMAC")
        self.gui:setButtonCallback("DownButton","cl_onDownMAC")
        self:refreshPage()
        self.gui:setOnCloseCallback("client_onClose")
		self.gui:open()
	end
end

function MACT.findPage(self , title)
    for k,v in pairs(MTt.book.titles)do
        if title == v then
            return k
        end
    end
    return 1
end

function MACT.refreshPage(self)
    local maxPage = #MTt.book.titles
    self.gui:setText("Title",MTt.book.titles[MTt.book.page])
    self.gui:setText("Description",MTt.book.scripts[MTt.book.page])
    self.gui:setSelectedDropDownItem("List", MTt.book.titles[MTt.book.page])
    self.gui:setImage("Tutorial","$MOD_DATA/Gui/Layouts/MACT/"..MTt.book.images[MTt.book.page])
    self.gui:setText("UpButton","UP - "..(MTt.book.page + maxPage-2)%maxPage+1)
    self.gui:setText("DownButton","DOWN - "..MTt.book.page%maxPage+1)
end

function MACT.cl_onDropDownInteract(self,DDname)
    MTt.book.page = self:findPage(DDname)
    self:refreshPage()
end

function MACT.cl_onUpMAC(self,button)
    local maxPage = #MTt.book.titles
    MTt.book.page = (MTt.book.page + maxPage-2)%maxPage+1
    self:refreshPage()
end

function MACT.cl_onDownMAC(self,button)
    local maxPage = #MTt.book.titles
    MTt.book.page = MTt.book.page%maxPage+1
    self:refreshPage()
end

function MACT.client_onClose(self)
    if self.gui then
        self.gui:close()
        self.gui:destroy()
        self.gui = nil
    end
end

function MACT.client_canInteract(self)
	sm.gui.setInteractionText("",sm.gui.getKeyBinding("Use",true),MLines.lines["Mtutorial"][MLines.currentLanguage][1],"")
	return true
end